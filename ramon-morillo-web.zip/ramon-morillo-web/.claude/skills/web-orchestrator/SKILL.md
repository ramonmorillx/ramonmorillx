---
name: web-orchestrator
description: Punto de entrada para construir de principio a fin (e2e) la web personal de Ramón Morillo (portfolio + blog + proyectos, frontend Node.js, backend Python, intro con agentes que construyen la web, Docker y publicación). Úsala cuando el usuario diga "empieza la web", "siguiente fase", "¿en qué punto estamos?", "construye la web" o cualquier tarea que no sepas a qué fase pertenece.
---

# Orquestador de la web de Ramón Morillo

Coordina las demás skills, mantiene el estado y garantiza que **se pregunta antes de asumir**.
Lee primero `AGENTS.md` en la raíz del repo: sus reglas prevalecen.

## Qué se construye (visión)

- **Carta de presentación** para empresas: quién es Ramón, qué hace, experiencia, proyectos, formación,
  stack, contacto.
- **Blog** de artículos técnicos y **sección de proyectos personales** que Ramón puede ampliar él mismo.
- **Intro animada**: al abrir la web, una "swarm" de cursores-agente con nombre construye la página
  delante del usuario (marcos con medidas, texto tecleado, imágenes arrastradas, recolor, check) con una
  píldora inferior que cuenta agentes y capas. Al terminar, la web queda navegable con normalidad.
- **Frontend** con Node.js, **backend** con Python, todo **dockerizado** y **publicado** con HTTPS y CI/CD.

## Flujo e2e (fases y puertas)

Cada fase tiene una *puerta*: no se pasa a la siguiente sin cumplirla.

| # | Fase | Skill | Puerta de salida |
|---|------|-------|------------------|
| 0 | Entorno local | `web-env-setup` | `node -v`, `python3 --version`, `uv --version`, `docker version`, `git` OK (o el usuario acepta seguir sin alguno) |
| 1 | Descubrimiento | `web-discovery` | `docs/brief.md` completo y **aprobado** por el usuario |
| 2 | Contenido | `web-content` | `content/` con textos ES/EN aprobados; lista de datos pendientes vacía |
| 3 | Repo GitHub | `web-github-repo` | identidad git personal configurada; remoto creado o descartado explícitamente |
| 4 | Estructura | `web-scaffold` | árbol de carpetas creado, `make help` funciona, primer commit |
| 5 | Backend | `web-backend` | `uv run pytest` verde, `/api/health` responde |
| 6 | Frontend | `web-frontend` | `npm run build` y `npm test` verdes, todas las páginas del brief existen |
| 7 | Intro agentes | `web-agent-intro` | `node render.mjs --check` con errors 0 y pass true; la web es navegable al acabar la intro |
| 8 | Docker | `web-docker` | `docker compose up --build` levanta todo y los healthchecks pasan |
| 9 | Calidad | `web-qa` | Lighthouse ≥ 90 en las 4 categorías, e2e verde, sin enlaces rotos |
| 10 | Publicación | `web-deploy` | URL pública con HTTPS, CI/CD desplegando desde `main` |

Las fases 5 y 6 pueden hacerse en paralelo si el contrato de la API (`docs/api.md`) está cerrado.
La fase 7 depende de que la home (fase 6) esté terminada: la intro es una captura 1:1 de la home real.

## Procedimiento al invocar esta skill

1. **Leer estado**: abre `docs/estado-proyecto.md`. Si no existe, créalo con la plantilla de abajo y
   empieza en la fase 0.
2. **Resumir** al usuario en 3-5 líneas: fase actual, qué falta, siguiente paso.
3. **Confirmar** con el usuario antes de empezar la fase (una pregunta: "¿Arranco la fase N: X?"),
   salvo que ya lo haya pedido explícitamente.
4. **Cargar la skill de la fase** y seguirla al pie de la letra.
5. **Verificar la puerta** de salida ejecutando los comandos reales. Si falla, arreglar e iterar.
6. **Actualizar** `docs/estado-proyecto.md` (fase, fecha, resultado de la verificación, pendientes)
   y hacer commit con mensaje convencional (`feat:`, `chore:`, `docs:`…). Antes del **primer** commit,
   comprueba `git config user.email` dentro del repo: si es la corporativa (@mapfre.com) o está vacía,
   pregunta nombre/email personal y fíjalos con `git config` local (ver `web-github-repo` §1-2).
7. Preguntar si continuar con la siguiente fase.

## Protocolo de preguntas (obligatorio)

- Pregunta cuando: falte un dato del perfil, haya varias opciones razonables de diseño/arquitectura,
  algo cueste dinero, algo sea irreversible (borrar, publicar, crear cuentas, DNS), o haya
  credenciales de por medio.
- No preguntes lo que ya está en `docs/brief.md` o `docs/decisiones.md`.
- Formato: bloque corto con contexto + preguntas con opciones + opción recomendada + "otra".
- Si el usuario no responde o dice "decide tú", aplica la recomendada **y anótalo** en
  `docs/decisiones.md` como "decidido por defecto".

## Lo que el agente NO puede hacer solo (pedirlo al usuario y explicar los pasos)

- Crear cuentas (GitHub personal, proveedor cloud, registrador de dominio) o pagar.
- Introducir contraseñas, tokens o claves SSH en sitios donde el agente no tenga acceso seguro.
- Cambiar DNS en el registrador si no hay API/credenciales.
- Descargar ficheros bloqueados por el proxy corporativo (ver `web-env-setup`).
- Aceptar licencias o términos de uso de terceros (p. ej. los scripts de agent-cursors).

En esos casos: da instrucciones paso a paso numeradas, espera confirmación y verifica después.

## Plantilla de `docs/estado-proyecto.md`

```markdown
# Estado del proyecto

| Fase | Estado | Fecha | Verificación |
|------|--------|-------|--------------|
| 0 Entorno | pendiente | | |
| 1 Descubrimiento | pendiente | | |
| 2 Contenido | pendiente | | |
| 3 Repo GitHub | pendiente | | |
| 4 Estructura | pendiente | | |
| 5 Backend | pendiente | | |
| 6 Frontend | pendiente | | |
| 7 Intro agentes | pendiente | | |
| 8 Docker | pendiente | | |
| 9 Calidad | pendiente | | |
| 10 Publicación | pendiente | | |

## Pendiente de respuesta del usuario
- (lista)

## Bloqueos
- (lista)
```

Estados válidos: `pendiente`, `en curso`, `hecho`, `bloqueado (motivo)`, `omitido (decisión del usuario)`.
