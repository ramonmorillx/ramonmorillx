---
name: web-docker
description: Dockeriza la web de Ramón Morillo (frontend Astro/Node, backend FastAPI/Python, PostgreSQL y Caddy como proxy inverso con HTTPS) con docker compose para desarrollo y producción, healthchecks, volúmenes y backups. Úsala en la fase 8 o ante cualquier cambio de Dockerfile, compose o Caddyfile.
---

# Fase 8 · Docker

Plantillas listas para adaptar en `templates/`:
| Plantilla | Destino en el repo |
|---|---|
| `Dockerfile.backend` | `backend/Dockerfile` (contexto `backend/`) |
| `Dockerfile.frontend` | `frontend/Dockerfile` (contexto = raíz del repo, porque necesita `content/`) |
| `docker-compose.yml` | `docker-compose.yml` |
| `docker-compose.prod.yml` | `docker-compose.prod.yml` |
| `Caddyfile` | `infra/caddy/Caddyfile` |
| `env.example` | `.env.example` (el usuario crea `.env` a partir de él; nunca se commitea) |
| `dockerignore` | `backend/.dockerignore` y `.dockerignore` raíz |

## 1. Preguntas
1. ¿Docker disponible? (`docker version`). Si no, volver a `web-env-setup` o posponer la fase.
2. ¿Local con HTTPS (`SITE_ADDRESS=localhost`, certificado interno de Caddy) o HTTP simple (`:80`, R)?
3. ¿PostgreSQL o SQLite? (debe coincidir con el brief). Con SQLite se elimina el servicio `db`.
4. Arquitecturas de imagen: solo `amd64` (R para VPS x86) o también `arm64` (Mac M/Raspberry/VPS ARM).

## 2. Procedimiento
1. Copia las plantillas a sus destinos y ajusta nombres/puertos si el scaffold difiere.
2. Requisito del frontend: las páginas que llaman a la API deben ser SSR (`prerender = false`) o tolerar
   que la API no exista durante `docker build` (en el build no hay backend).
3. `cp .env.example .env` y pide al usuario que rellene los secretos (él mismo; tú solo indicas cómo
   generarlos: `openssl rand -hex 32`, hash argon2 de `web-backend`).
4. `docker compose up --build -d` → `docker compose ps` (todos `healthy`) → pruebas:
   `curl -fsS localhost/api/health`, `curl -fsS localhost/ | grep -i "Ramón"`, subir una imagen desde el
   admin y abrir `/uploads/...`, enviar un contacto.
5. Seed opcional: `docker compose exec backend python scripts/seed.py`.
6. Backups (producción): `docker compose exec db pg_dump -U $POSTGRES_USER $POSTGRES_DB | gzip > backup.sql.gz`
   + copia del volumen `uploads`; `web-deploy` lo programa con cron.

## 3. Reglas
- Imágenes mínimas (`-slim`/`-alpine`), multi-stage, usuario no root, `HEALTHCHECK`, sin secretos en
  capas ni `ARG` (solo variables de entorno en runtime).
- La BD no expone puertos en producción. Caddy es el único servicio con puertos públicos (80/443).
- `X-Frame-Options: SAMEORIGIN` (no `DENY`): la intro usa un iframe del mismo origen.
- Versiones de imagen fijadas (p. ej. `postgres:17-alpine`, `caddy:2.8-alpine`), actualizadas por Dependabot.

## Puerta de salida
`docker compose up --build` levanta todo con healthchecks en verde, las pruebas del paso 2.4 pasan, y
`docker compose down && docker compose up -d` conserva datos (volúmenes). Commit `build: docker`.
