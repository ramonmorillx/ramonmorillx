# Brief original de "agent cursors" (texto literal aportado por Ramón, no modificar)

Este es el procedimiento de referencia. La skill `web-agent-intro` lo adapta a este proyecto
(intro al abrir la web + navegación normal al terminar). En este proyecto aplica el **Path A**
(capturar la home real); el Path B solo se usa si no existiese página.

Diferencias con este repo: los scripts ya están en `tools/agent-cursors/` (no hay que descargarlos ni crear
`agent-build/`); `capture.mjs` escribe un `index.html` que **enlaza** `agents.js` (no lo copia: debe estar en la
misma carpeta, como ya ocurre); `capture.mjs` admite además `--label=<dominio>` (ver `SOURCE.md`).

---

Turn my website into a video of AI agents building it live in the browser.

The result: a swarm of named agent cursors builds my real page from nothing, 1:1 as it is. They draw frames with size labels, type the text, drag in images, resize, recolor and check, while a pill at the bottom counts agents and layers. I get (a) a local page that plays this in my browser and (b) finished MP4s in 16:9 and 9:16.

My input is at the very end of this message: a URL, a local project path or a short description. If it is missing, ask for it once. Do everything below yourself and do not stop before the MP4s exist.

## 1. Set up
mkdir -p agent-build/assets && cd agent-build
curl -fsSLO https://visionpictures.net/free/agent-cursors/agents.js
curl -fsSLO https://visionpictures.net/free/agent-cursors/render.mjs
curl -fsSLO https://visionpictures.net/free/agent-cursors/capture.mjs
If the env var PLAYWRIGHT_PATH is not set, also run: npm init -y && npm i playwright ffmpeg-static && npx playwright install chromium
Keep agents.js and render.mjs unchanged. Keep all browser work headless.

## 2. Make index.html: take path A or path B

### Path A: my input is a URL or a local project. The real page, 1:1.
You do not write the page. Run:
node capture.mjs <the URL or path>
For a project that needs a dev server, start it first and pass its localhost URL. The tool freezes the real page into index.html and assets/ and adds agents.js.
Texts, images, colors, fonts, order and layout stay exactly as in the original. Nothing is invented, shortened, restyled or beautified. Never edit index.html by hand.

### Path B: my input is only a description, there is no page yet.
Only here you write index.html yourself: one static page, the finished site. agents.js turns it into the build by itself.
Copy: from the description alone, in its language. Never invent numbers, prices, reviews, customers or awards. No third-party brands or logos. If a fact is missing, leave that element out.
Images: draw each one yourself as a detailed SVG file in assets/, in the brand colors, no placeholders.
Layout: fixed 1920px wide, all sizes in px, content column width:1500px;margin:0 auto.
Type: h1 130-170px, weight 700+, line-height .92, tight letter-spacing. h2 72-88px. Card titles 30-36px. Body 20-24px. Nothing under 15px.
Look: a distinctive palette. It must look like the work of a premium studio, with strong contrast.
Sections, in this order:
1. Header, 92px high: logo, 4-5 links, button.
2. Hero, 930px high, position:relative. Left: small label, h1 of at most 5 words, one sentence, two buttons. Right: a big composition of 3-5 overlapping images or cards. Behind it, at position:absolute;left:770px;top:150px: one giant brand word (300px, weight 800, gradient text with background-clip:text, may run off the right edge, never behind the left column), plus a soft radial glow in an empty <div>.
3. Three benefit cards: SVG icon, title, text.
4. h2, one short sentence, then four large offer cards: image, small label, title, text, price or note, button.
5. h2, then a grid of 8 images.
6. Four process or FAQ cards: icon or step, title, text.
7. Closing box: h2, one short sentence, button, small note.
8. Footer: brand line and 4 link columns with 4 links each.
Required, or the build breaks:
- Cards and buttons have their own background, border and border-radius.
- Every piece of text sits in its own element, and each link is its own <a>.
- In each h1 and h2, wrap the key word in <em> and give it the accent color.
- No animation, transition, ::before, ::after, position:fixed, position:sticky, vw, vh, clamp() or media queries. No scripts of your own.
- No overflow:hidden around images. Put border-radius and object-fit:cover on the <img>.
- No transform on images or text. To rotate one, wrap it in a <div> and rotate the div.
- Last line inside <body>: <script src="agents.js" data-accent="#HEX"></script>

## 3. Check
Run: node render.mjs --check
It prints JSON and saves stills to out/check/. It exits with code 1 while a requirement fails. Required in both paths: errors 0.
- Path A: "deviation" measures the finished build against the original at the same scroll spots, and "pass" must be true. "pass" alone is not enough: look at every out/check/compare-*.jpg once (left original, right build). Judge what you can see at that size, without zooming in. A moving part of the original (carousel, video, an effect that follows the mouse or the scroll) may show the same content in another moment. A missing, shifted, cut off or recolored element is an error, even if it is small. Then the tool is wrong: find which element differs, fix the general rule in capture.mjs for it and run capture.mjs again. Never rewrite or patch the page by hand.
- Path B: layers 120 or more. With fewer, add real elements. Look at out/check/16x9-05.jpg to 08.jpg, the finished page from bottom to top: it must look premium, with nothing cut off or overlapping. Fix index.html and check again.

## 4. Render
Only after step 3 passes. Start both in the background. They take minutes and can run side by side:
nohup node render.mjs > out/16x9.log 2>&1 &
nohup node render.mjs --vertical > out/9x16.log 2>&1 &
Wait until each log ends with a JSON line that contains "video". If the log shows that a render would take over 20 minutes, restart it with --fast. If no ffmpeg exists, render.mjs saves the frames and prints the exact command that finishes the job.

## 5. Hand over
Give me the paths of out/agents-16x9.mp4 and out/agents-9x16.mp4. Tell me to double-click index.html to watch it live in the browser (F fullscreen, R restart, Space pause).
