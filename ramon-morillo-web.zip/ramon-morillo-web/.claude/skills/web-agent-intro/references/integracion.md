# Integración de la intro de agentes en la web

## Arquitectura
```
/ (home real, HTML completo desde el servidor)
 └─ <IntroOverlay> (script inline, solo en la home)
      ├─ escritorio: <iframe src="/intro/index.html?tempo=X&chrome=0"> a pantalla completa
      │               agents.js escala solo el escenario de 1920 px al ancho de la ventana
      ├─ móvil reel:  <iframe src="/intro/index.html?...&reel=1"> 1080×1920 escalado con transform para caber
      ├─ móvil video: <video src="/video/agents-9x16.mp4" muted autoplay playsinline>
      ├─ botón "Saltar intro" + Esc
      └─ fin: AG_READY → AG.info().dauer → fundido → elimina overlay → scroll libre → foco en <main>
```
Por qué iframe: aísla la captura (fija a 1920 px, sin media queries, CSS propio de agents.js) de la web real
responsive, y `agents.js` funciona exactamente igual que al abrir `index.html` con doble clic. Es mismo
origen, así que el padre lee `iframe.contentWindow.AG`.

**Verificado el 2026-11-23** con una página de prueba servida en local, en un navegador real:
- Escritorio 801 px, `tempo=4`: la build se escala al ancho, el overlay se cierra solo a los ~10,9 s
  (duración real; no saltó el timeout de seguridad), el foco pasa a `<main>`, el scroll se desbloquea y la
  navegación funciona.
- Móvil 390×844, `reel=1`: el iframe se escala a 390×693 y se ve "16 AI agents. One website. Live." con la
  píldora. El botón "Saltar intro" cierra el overlay al momento.

## API detectada de agents.js (inspección del código, 2026-11-23)
| Elemento | Detalle |
|---|---|
| Listo | `window.AG_READY = true` cuando la build está preparada (en live, el reloj arranca ~20 fotogramas después y pone `AG.laeuft = true`) |
| Duración | `AG.info()` → `{ dauer, bauEnde, scroll:[s0,s1], agenten, ebenen, aufgaben, seitenH, tempo }` en segundos, ya divididos por `tempo`. `bauEnde` = fin de la construcción; después la cámara recorre la página terminada de abajo arriba y acaba en `y = 0` |
| Fin | **No hay evento ni postMessage.** En live el reloj se limita a `dauer` y se queda en el último fotograma (no repite). La píldora pasa de `building` a `done` en `bauEnde` y se desvanece al final del recorrido |
| Control | `AG.tick(t)` pinta el instante `t` (lo usa `render.mjs`). Teclas en live: `R` reinicia, `Espacio` pausa/reanuda, `F` pantalla completa |
| URL | `?tempo=<x>` acelera (2 = mitad de duración) · `?chrome=0` oculta la barra de navegador simulada (82 px) · `?reel=1` formato vertical 1080×1920 con titular "N AI agents. One website. Live." · `?seed=<n>` cambia la coreografía · `?t=<s>` empieza en el segundo s · `?render=1` modo fotograma a fotograma (render.mjs) |
| Atributos del `<script>` | `data-accent="#HEX"` (si falta, toma el color del primer botón/enlace con fondo, o `#FF5A0A`) · `data-title` (título de pestaña simulada) · `data-url` (barra de dirección; por defecto `localhost:3000` → usar `capture.mjs --label=`) |
| Escalado | Escritorio: escenario de 1920 px escalado a `innerWidth`, recalcula al redimensionar. Reel: lienzo fijo 1080×1920 sin escalado propio (lo escala el overlay) |
| Red | Ninguna petición externa; fuentes Geist embebidas (SIL OFL 1.1) |

## Decisiones a confirmar con el usuario
| Tema | Opciones | Recomendado |
|---|---|---|
| Duración | `tempo` 1 (original) … 2 (mitad) | Que la intro dure 15-25 s: `tempo = seconds / 20` redondeado a 0,25 (con `seconds` de `render.mjs --check`) |
| Alcance | (a) home completa, (b) solo cabecera + hero vía `/intro-source` | (a) si con tempo ≤ 2 queda en ≤ 25 s; si no, (b) |
| Barra de navegador simulada | visible (`chrome=1`) / oculta (`chrome=0`) | Oculta en la web (el final coincide mejor con la página real); visible en los MP4 |
| Frecuencia | `always` / `session` / `forever` | `session` |
| Móvil | `reel` (vertical en vivo) / `video` (MP4 9:16 comprimido) / `none` | `reel`: sin descarga de vídeo; si va lento en móviles modestos, `video` |
| Transición final | fundido 600 ms | La build termina arriba del todo (`y = 0`), igual que la home al cargar: el cambio es casi invisible a 1920 px |

## Tiempos útiles
- Duración de la intro en la web ≈ `seconds / tempo` + ~0,4 s.
- `render.mjs` siempre renderiza a tempo 1 (no pasa `?tempo`); los MP4 duran `seconds`.
