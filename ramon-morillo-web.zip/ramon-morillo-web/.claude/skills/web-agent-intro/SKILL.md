---
name: web-agent-intro
description: Crea la intro animada de la web de Ramón Morillo en la que una swarm de cursores-agente con nombre construye la home real 1:1 (agent cursors de visionpictures.net - tools/agent-cursors/agents.js, capture.mjs, render.mjs), la integra como overlay al abrir la web con salto y fin automático para navegar con normalidad, y genera los MP4 16:9 y 9:16. Úsala en la fase 7, al cambiar la home (regenerar captura) o para producir los vídeos para redes.
---

# Fase 7 · Intro "agentes construyendo la web"

- Procedimiento base (literal, en inglés): `references/brief-original-agent-cursors.md`. Aquí se aplica el
  **Path A** (capturar la home real) y se añade la integración como intro.
- API real de `agents.js`, parámetros y decisiones: `references/integracion.md` (**léelo antes de empezar**).
- Plantilla del overlay (probada en navegador en escritorio y móvil): `templates/IntroOverlay.astro`.

## Requisitos previos
- Home terminada y aprobada (fase 6).
- Respuestas del bloque H del brief (frecuencia, móvil, tempo, barra de navegador, MP4, licencia). Si faltan, **pregunta**.

## 1. Scripts (ya en el repo)
`tools/agent-cursors/` contiene `agents.js`, `render.mjs` y `capture.mjs` (recibidos el 2026-11-23; el proxy
corporativo bloquea su descarga). Antes de usarlos:
```bash
cd ~/proyectos/ramon-morillo-web/tools/agent-cursors && sha256sum agents.js render.mjs capture.mjs
```
y compara con `SOURCE.md`. Si no coinciden, **detente y pregunta**.
- `agents.js` y `render.mjs`: **no se modifican nunca**.
- `capture.mjs`: tiene una modificación local documentada (`--label=`). Las correcciones de fidelidad se hacen
  aquí como reglas generales y se documentan en `SOURCE.md`.
- Licencia: si `SOURCE.md` sigue marcando la confirmación de términos como pendiente, pregunta a Ramón
  antes de publicar (fase 10). No bloquea el trabajo en local.

## 2. Dependencias (headless siempre)
```bash
cd tools/agent-cursors
[ -f package.json ] || npm init -y
[ -n "$PLAYWRIGHT_PATH" ] || { npm i -D playwright ffmpeg-static && npx playwright install chromium; }
```
Commitea `package.json` y `package-lock.json` (no `node_modules/`). Si el proxy bloquea
`playwright install`, pide al usuario que lo ejecute desde red personal o que defina `PLAYWRIGHT_PATH`.

## 3. Capturar la home (Path A)
```bash
# terminal 1 · servir la web real
cd frontend && npm run build && npm run preview -- --port 4321
# terminal 2 · congelar la home a 1920 px
cd tools/agent-cursors && node capture.mjs "http://localhost:4321/?capture=1" --label=<dominio-final>
```
- Escribe `index.html` + `assets/` en `tools/agent-cursors/` y las capturas de referencia en `out/original/`
  (`shots.json`). El `index.html` ya enlaza `agents.js` (que está en la misma carpeta) con `data-accent`,
  `data-title` y `data-url`. **Nunca editar `index.html` a mano.**
- `?capture=1` deja las animaciones de scroll de la web en su estado final y hace que el overlay no se
  dispare durante la captura.
- `--label=` pone el dominio real en la barra de navegador simulada (si no, sale `localhost:3000`).
- La salida JSON informa `height`, `elements`, `images`, `imagesFailed`, `accent`. `imagesFailed > 0` → investigar.
- Intro solo de cabecera + hero (si se decide así, ver `integracion.md`): capturar
  `http://localhost:4321/intro-source?capture=1`.

## 4. Comprobar
```bash
node render.mjs --check      # exit 1 mientras falle algo
```
- JSON: `seconds` (duración a tempo 1), `agents`, `layers`, `errors`, `deviation{changedPixelsPct, worst, pass}`.
  Obligatorio `errors: 0` y `deviation.pass: true` (media de píxeles cambiados ≤ 5 % y peor posición ≤ 30 %).
- Mira **cada** `out/check/compare-*.jpg` (izquierda original, derecha build) sin hacer zoom. Un elemento
  ausente, desplazado, cortado o recoloreado es un error aunque sea pequeño. Partes móviles (carrusel, vídeo,
  efectos de ratón/scroll) pueden mostrar otro instante y no cuentan.
- Si hay error: corrige la **regla general** en `capture.mjs` (documenta en `SOURCE.md`) o la maquetación de la
  home según `web-frontend` §5, recaptura y repite. Nunca parchear `index.html`.
- Mira también `out/check/16x9-01..08.jpg` (1-4 construcción, 5-8 página terminada de abajo arriba).
- Muestra al usuario 2-3 capturas y el resumen (segundos, agentes, capas, deviation). Con `seconds` decide
  con él el `tempo` de la intro web (ver `integracion.md`).

## 5. Integrar como intro de la web
1. `make intro-capture` copia la captura a la web:
   `rm -rf frontend/public/intro && mkdir -p frontend/public/intro && cp -r tools/agent-cursors/{index.html,agents.js,assets} frontend/public/intro/`
   (`frontend/public/intro/` **sí** se commitea; la copia de trabajo de `tools/` no).
2. `/intro/` fuera de buscadores: `Disallow: /intro/` en `robots.txt` + cabecera `X-Robots-Tag: noindex` (Caddyfile de `web-docker`).
3. Copia `templates/IntroOverlay.astro` a `frontend/src/components/` y úsalo **solo en la home**, al final del `<body>`:
   `<IntroOverlay tempo={1.5} chrome={false} mobile="reel" once="session" skipLabel="Saltar intro" />`
   (valores según el brief; en la versión EN `skipLabel="Skip intro"`).
4. Comportamiento (ya implementado en la plantilla; no romperlo):
   - El contenido real está en el HTML desde el principio (SEO, sin JS); el overlay lo inyecta JS.
   - No se reproduce con `prefers-reduced-motion`, `?nointro`, `?capture`, bots/Lighthouse, ni si ya se vio (según `once`).
   - Fin automático: espera `AG_READY` en el iframe, lee `AG.info().dauer` y cierra tras esa duración + `holdMs`.
     Si `agents.js` no arranca en `readyTimeoutMs`, cierra. Botón "Saltar intro" + `Esc` siempre.
   - Al cerrar: fundido 600 ms, se elimina del DOM, se desbloquea el scroll y el foco pasa a `<main>`.
   - Móvil (≤ 768 px): `reel` = vertical en vivo escalado (probado), `video` = MP4 9:16, `none` = sin intro.

## 6. Renderizar MP4 (solo tras pasar el paso 4)
```bash
cd tools/agent-cursors && mkdir -p out
nohup node render.mjs > out/16x9.log 2>&1 &
nohup node render.mjs --vertical > out/9x16.log 2>&1 &
```
- Espera a que **cada** log termine con una línea JSON que contenga `"video"`. El log imprime `frame i/N  t s`
  cada 120 fotogramas: estima el total; si supera 20 min, reinicia ese render con `--fast`.
  `--until <s>` renderiza solo los primeros segundos (útil para pruebas). `--gpu` es más rápido pero puede perder capas.
- Sin ffmpeg, `render.mjs` guarda los fotogramas y imprime el comando exacto para terminar.
- Resultado: `out/agents-16x9.mp4` (3840×2160, 60 fps), `out/agents-9x16.mp4` (1080×1920) y `out/sheet-*.jpg`.
- Si el brief elige `mobile="video"`, comprime antes de publicarlo (el original pesa decenas de MB):
  `ffmpeg -i out/agents-9x16.mp4 -vf scale=720:-2 -c:v libx264 -crf 28 -preset slow -an -movflags +faststart ../../frontend/public/video/agents-9x16.mp4` (objetivo ≤ 4 MB).

## 7. Verificación (puerta de salida)
- `render.mjs --check`: errors 0, deviation.pass true, compare-*.jpg revisados.
- Test Playwright de la home (`frontend/tests/e2e/intro.spec.ts`):
  1. `/` en 1440×900 → `.rm-intro` visible → `waitForSelector('.rm-intro', { state: 'detached', timeout: dauer/tempo + 5 s })`
     → `html` sin `rm-intro-open` → clic en el menú navega a `/blog`.
  2. Botón "Saltar intro" elimina el overlay en < 1 s.
  3. `?nointro` y `reducedMotion: 'reduce'` → no hay overlay.
  4. Viewport 390×844 → iframe con `reel=1` escalado (ancho ≤ 390).
- Lighthouse de la home ≥ 90 en rendimiento (Lighthouse no ve la intro por el filtro de UA, pero mide el peso).
- Entrega: rutas de los MP4 y "abre `tools/agent-cursors/index.html` con doble clic para verlo en vivo
  (F pantalla completa, R reiniciar, Espacio pausa)".

## Mantenimiento
Cada cambio visual en la home → `make intro-capture && make intro-check` y commit de `frontend/public/intro/`.
El CI (`web-qa`/`web-deploy`) comprueba que la intro publicada no tiene errores.
