---
name: web-deploy
description: Publica la web de Ramón Morillo en Internet - elección de hosting, dominio y DNS, servidor con Docker, HTTPS con Caddy, CI/CD con GitHub Actions (imágenes en GHCR y despliegue por SSH), backups, monitorización y rollback. Úsala en la fase 10, para redesplegar, o si algo falla en producción.
---

# Fase 10 · Publicación

Ruta recomendada (decidir con el usuario, bloque J del brief): **VPS + Docker Compose + Caddy + GHCR +
GitHub Actions**. Alternativas al final.

## Quién hace qué
| Paso | Usuario (no automatizable) | Agente |
|---|---|---|
| Cuenta en proveedor VPS (Hetzner/DigitalOcean…) y pago | ✅ | explica |
| Comprar dominio | ✅ | recomienda (.dev/.com/.es) |
| Crear servidor y añadir tu clave SSH pública | ✅ (panel web) | genera instrucciones y la clave si se pide |
| Registros DNS A/AAAA | ✅ (o agente vía API si hay token) | indica valores |
| Preparar servidor (docker, firewall, usuario deploy) | | ✅ por SSH si el usuario da acceso |
| Secretos en GitHub | ✅ pega valores | ✅ lista nombres |
| Workflows CI/CD, primer despliegue, verificación | | ✅ |

## 1. Preguntas (si no constan)
1. Proveedor y región (R: Hetzner CX22, Alemania/Finlandia, ~4-5 €/mes; 2 vCPU, 4 GB).
2. Dominio exacto y registrador. ¿`www` redirige al dominio raíz (R) o al revés?
3. ¿Imágenes GHCR públicas (R, el código ya es público) o privadas (requiere `docker login` en el servidor)?
4. ¿Email para avisos de Let's Encrypt/alertas?
5. ¿Monitorización externa gratuita (UptimeRobot/Better Stack) sobre `/api/health`? (R: sí)

## 2. Preparar el servidor (Ubuntu 24.04), una sola vez
```bash
# como root, recién creado
adduser --disabled-password --gecos "" deploy && usermod -aG sudo deploy
mkdir -p /home/deploy/.ssh && cp ~/.ssh/authorized_keys /home/deploy/.ssh/ && chown -R deploy: /home/deploy/.ssh
sed -i 's/^#\?PasswordAuthentication .*/PasswordAuthentication no/; s/^#\?PermitRootLogin .*/PermitRootLogin no/' /etc/ssh/sshd_config && systemctl restart ssh
ufw allow OpenSSH && ufw allow 80 && ufw allow 443 && ufw --force enable
curl -fsSL https://get.docker.com | sh && usermod -aG docker deploy
apt-get install -y unattended-upgrades fail2ban
# como deploy
sudo mkdir -p /opt/ramon-morillo-web && sudo chown deploy: /opt/ramon-morillo-web
git clone https://github.com/ramonmorillx/ramon-morillo-web.git /opt/ramon-morillo-web
cp /opt/ramon-morillo-web/.env.example /opt/ramon-morillo-web/.env   # el usuario rellena: ENV=production, SITE_ADDRESS=dominio…
```
Genera una clave SSH **exclusiva para el despliegue** (`ssh-keygen -t ed25519 -f deploy_key -N ""`),
añade la pública a `/home/deploy/.ssh/authorized_keys` y la privada como secreto `DEPLOY_SSH_KEY`.

## 3. DNS
`A @ → IPv4`, `AAAA @ → IPv6`, `CNAME www → @`. Comprobar: `dig +short dominio A`. Caddy pide el
certificado solo cuando el DNS ya apunta al servidor y los puertos 80/443 están abiertos.
Para `www → raíz`, añadir al Caddyfile: `www.{$SITE_ADDRESS} { redir https://{$SITE_ADDRESS}{uri} permanent }`.

## 4. CI/CD
Copiar `templates/ci.yml` y `templates/deploy.yml` a `.github/workflows/`.
Secretos (Settings > Secrets > Actions): `DEPLOY_HOST`, `DEPLOY_USER` (=deploy), `DEPLOY_SSH_KEY`,
`DEPLOY_PATH` (=/opt/ramon-morillo-web). Variable: `SITE_URL` (https://dominio).
Flujo: push a `main` → CI (tests) → build y push de imágenes `:sha` y `:latest` a GHCR → SSH al servidor →
`git pull` (compose/Caddyfile) → `docker compose pull && up -d` → comprobación de salud → si falla, rollback.

Primer despliegue: tras configurar secretos, `gh workflow run deploy.yml` y seguir con `gh run watch`.
Si las imágenes GHCR quedan privadas por defecto: GitHub > Packages > paquete > Settings > Change visibility.

## 5. Después del despliegue
- Verificar: `curl -fsSI https://dominio | head -1` (200), `curl -fsS https://dominio/api/health`,
  certificado válido, intro visible en primera visita, formulario de contacto envía.
- Backups diarios (cron del usuario deploy):
  `0 3 * * * cd /opt/ramon-morillo-web && docker compose exec -T db pg_dump -U web web | gzip > ~/backups/db-$(date +\%F).sql.gz && find ~/backups -mtime +14 -delete`
  y copia semanal del volumen `uploads`. Recomienda copia fuera del servidor (snapshot del proveedor o rclone).
- Rollback manual: `IMAGE_TAG=<sha anterior> docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d`.
- Alta en Google Search Console y envío de `sitemap-index.xml`; perfil de LinkedIn/GitHub con la URL.
- Documentar todo en `docs/despliegue.md` (runbook: IPs, dominios, cómo desplegar, restaurar backup, rotar secretos).

## Alternativas (si el usuario no quiere administrar un servidor)
| Opción | Cómo | Pros / contras |
|---|---|---|
| PaaS (Render / Railway / Fly.io) | 2 servicios Docker (frontend, backend) + Postgres gestionado; dominio propio en el panel | Sin servidor que mantener; coste mayor (~15-25 €/mes) y límites del plan gratuito |
| Cloudflare Pages + PaaS backend | frontend estático/SSR en Pages, API en Fly/Render | CDN global gratis; más piezas y CORS |

## Puerta de salida
URL pública con HTTPS, `deploy.yml` verde, healthcheck externo activo, backup probado (restaurar en local
una vez) y `docs/despliegue.md` escrito.
