# Perfil verificado · Ramón Morillo

Extraído el 2026-11-23 de `~/projects/cv.tex` (principal) y de sus variantes `cv_v1_clasico.tex`,
`cv_v2_logros.tex`, `cv_v3_proyectos.tex`, `cv_v4_competencias.tex`, `cv_v5_dos_columnas.tex`.
Solo se usan estos datos. Lo que no esté aquí → preguntar.

## Identidad y contacto
- Nombre: **Ramón Morillo**
- Rol: **AI Engineer** (puesto: *Data & AI Scientist* en MAPFRE)
- Ubicación: Madrid, España
- Email: ramonvejer@gmail.com · Teléfono: +34 630 376 301 (⚠️ preguntar si se publica; recomendado no)
- LinkedIn: https://linkedin.com/in/ramón-morillo-72b194273/
- GitHub: https://github.com/ramonmorillx
- Idiomas: Español (nativo). ⚠️ El CV no lista inglés → preguntar.
- Foto: ninguna en los CVs → preguntar.

## "Sobre mí" (variantes del CV, para elegir/combinar)
- **Principal**: AI Engineer con experiencia en machine learning, IA generativa y visión artificial aplicados
  a soluciones en producción para el sector asegurador. Combina formación en Economía y Ciencia de Datos con
  ingeniería de datos y MLOps para llevar modelos antifraude y de procesamiento documental del prototipo a
  producción. Experiencia en el ciclo de vida completo de modelos: ingeniería de variables, despliegue,
  monitorización y CI/CD.
- **v1**: Convierte datos y modelos de IA en herramientas de uso diario: sistemas que detectan posibles
  fraudes, que leen y ordenan documentos automáticamente o que revisan fotografías de vehículos. Se ocupa
  del proceso completo, desde entender el problema de negocio hasta dejar la solución funcionando.
- **v2**: IA que resuelve problemas reales de una aseguradora: detectar siniestros sospechosos antes de
  pagarlos, ahorrar horas de revisión manual de documentos y dar a los equipos información fiable para decidir.
- **v3**: Parte siempre de una pregunta de negocio: qué problema resolvemos y cómo sabremos que funciona.
- **v4**: Lleva la IA del prototipo al uso diario, demuestra con datos si aporta valor y se asegura de que
  los modelos sigan acertando con el tiempo.
- **v5**: Especializado en IA aplicada a seguros; datos, modelo, puesta en marcha y seguimiento de
  resultados. Visión de negocio (Economía) + autonomía técnica de principio a fin.

## Experiencia
### Data & AI Scientist · MAPFRE · Madrid · feb. 2025 – actualidad
⚠️ Nombres internos y cifras: confirmar permiso de publicación (brief, bloque D).

1. **Fraud Auto / Fraude en Autos** — Detección de fraude y MLOps
   - Modelo que puntúa a diario cada siniestro nuevo con lesiones leves y lo clasifica en **5 niveles de
     riesgo** para que los investigadores prioricen; evolucionado de árbol de decisión a **LightGBM**.
   - Pipeline e2e: imputación, selección de variables, optimización de hiperparámetros.
   - CI/CD con promoción y rollback entre entornos; **grupo de control (A/B)** para medir impacto real;
     monitorización de drift; panel en **Streamlit** y **Snowflake Model Monitor / Snowflake ML**; Airflow.
2. **Fraud Graph / Fraude Organizado** — Ingeniería de datos a escala
   - Flujo nocturno automatizado que relaciona siniestros, personas y vehículos en varias ventanas de tiempo
     para descubrir grupos que actúan juntos; histórico diario y de reservas económicas; datos por niveles de
     calidad. **PySpark, Snowpark, EMR Serverless, Snowflake, Airflow**; validación de calidad de datos.
3. **Document AI** — Clasificación documental con IA generativa
   - Pipeline OCR + LLM para documentos textuales y modelos vision-language para imágenes.
   - Afinado de **25 categorías a 175 subcategorías** con **Gemini**, con fallback automático a **GPT**.
   - Arquitectura hexagonal en **AWS Lambda**, prompts versionados, priorización y detección de urgencia.
   - Banco de pruebas de prompts sobre **687 documentos reales**.
4. **Asistente CGU** — IA para suscripción de seguros
   - Módulo de Protección de Alquileres (OpenAI): lee correos y adjuntos (PDF, Word, Excel, imágenes),
     distingue cotización de emisión, comprueba documentación; reutiliza análisis previos. Ampliado a Comercios.
5. **Vehicle Vision** — Visión artificial para peritaciones
   - Servicio que detecta vehículos sucios en fotografías (dificultan valorar daños previos):
     **Swin Transformer V2**, **ONNX**, umbrales de confianza configurables por clase.
6. **Salud** — Fraude y conversión
   - Plataforma de detección de anomalías/fraude en salud: ETL de 5 etapas en PySpark + app web con IA
     generativa (OpenAI) para interpretar anomalías (en v1-v5 figura como *colaboración/participación*).
   - Modelo predictivo mensual de conversión/contratación de seguros de salud para Pricing (**AWS SageMaker**).

## Formación
- **MSc Ciencia de Datos** · CUNEF Universidad (Escuela Politécnica Superior) · Madrid · 2024–2025 ·
  Nota **9,35**. TFM: *Métodos de ajuste en modelos de aprendizaje supervisado ante desbalanceo de clases,
  aplicando generación sintética para incrementar la captura de fraude.*
- **Grado en Economía** · Universidad de Granada (Facultad de Ciencias Económicas) · 2020–2024 · Nota **9**.
  Mención en Econometría y Estadística con **Matrícula de Honor**.

## Stack (unión de todas las variantes)
- Lenguajes/datos: Python, SQL, PySpark, pandas, Snowflake/Snowpark
- ML: LightGBM, scikit-learn, PyTorch, ONNX, Swin Transformer V2
- IA generativa: OpenAI (GPT), Gemini, LangChain, prompt engineering, evaluación de prompts
- Cloud/MLOps: AWS (Lambda, S3, EMR Serverless, SageMaker), Snowflake (ML Registry, Model Monitor),
  Airflow, Docker, GitHub Actions, CI/CD
- Apps/APIs: FastAPI, Streamlit

## Especialización / puntos fuertes (frases del CV)
- MLOps y CI/CD · IA generativa y LLMs · Visión artificial · Detección de fraude
- Áreas de negocio: fraude en autos y salud, gestión documental de siniestros, suscripción de seguros
- Del problema de negocio a producción · Medición del impacto real · Seguimiento continuo de modelos
- "Qué aporto": llevar la IA al uso diario · demostrar si la IA aporta valor · vigilar que los modelos acierten

## Lo que NO hay en los CVs (preguntar si se quiere incluir)
- Artículos, publicaciones, ponencias, docencia, premios, proyectos personales/open source, demos públicas,
  certificaciones, experiencia anterior a 2025, inglés u otros idiomas, foto, hobbies.
