# Análisis de la web de referencia: raulartigues.com

Revisado el 2026-11-23 (SPA React; contenido extraído del bundle). **Solo inspiración de contenido.**
No copiar textos, estilo, colores ni maquetación: Ramón quiere un estilo más moderno.

## Qué información presenta (checklist de secciones)
| Bloque en la referencia | Qué aporta | Equivalente para Ramón |
|---|---|---|
| Hero con nombre, rol ("Computer Vision Engineer & Senior Data Scientist") y frase de valor de negocio | Posicionamiento en 5 segundos | Nombre + "AI Engineer" + frase de valor del CV |
| Sobre mí con historia personal y foto | Cercanía | Bio del CV (+ foto si la aporta) |
| Experiencia (empresas: MAPFRE, Naturgy…) con ubicación | Credibilidad | MAPFRE, Madrid |
| Destacados / Featured (proyecto premiado, liderazgo) | Prueba social | "Logros clave" del CV v2 (si se autorizan) |
| Proyectos con demo (Hugging Face Spaces), vídeo, póster, PDF | Evidencia tangible | Proyectos personales (preguntar) |
| Blog técnico con filtros, lista de entradas y lectura completa, figuras, PDFs | Autoridad técnica | Blog con etiquetas, filtros y RSS |
| Publicaciones técnicas / papers (SSRN), TFG/TFM con nota | Rigor académico | TFM CUNEF (9,35), Grado UGR (9, MH) |
| Ponencias y colaboración (universidades, foros) | Visibilidad | Solo si Ramón las tiene (preguntar) |
| Habilidades (conocimiento, actitud, comunicación) | Perfil completo | Stack + especialización + "qué aporto" |
| Contacto con formulario (nombre, correo, asunto, mensaje) y mensajes de éxito/error | Conversión | Formulario → backend Python |
| Redes: GitHub, LinkedIn, Hugging Face | Canales | GitHub, LinkedIn |
| Selector de idioma ES/EN | Alcance internacional | ES/EN (confirmar) |
| Asistente IA (chat) | Diferenciación | Opcional, no en v1 (confirmar) |
| Navegación principal + menú móvil + botón "subir" + "Todos los derechos reservados" | Usabilidad | Igual, con estilo propio |

## Cómo diferenciarse (estilo más moderno)
- La intro de agentes construyendo la web ya es el elemento diferencial: el resto debe ser limpio.
- Tipografía grande y con carácter, rejilla clara, mucho aire, un solo color de acento potente.
- Tarjetas de proyecto con imagen, etiquetas de stack y enlaces claros (código / demo / artículo).
- Modo oscuro por defecto, transiciones suaves, `prefers-reduced-motion` respetado.
