---
name: web-content
description: Redacta y organiza el contenido (textos ES/EN, estructura de secciones, datos del perfil) de la web de Ramón Morillo a partir de sus CVs y del brief, sin inventar nada. Úsala para escribir o revisar cualquier texto de la web, el hero, la bio, la experiencia, proyectos, formación, stack o SEO.
---

# Fase 2 · Contenido

## Fuentes (en este orden de autoridad)
1. Lo que Ramón diga explícitamente (queda en `docs/brief.md`).
2. `references/perfil-ramon-morillo.md` — hechos extraídos de sus CVs, con la fuente de cada uno.
3. Los CVs originales en `~/projects/cv.tex` y `~/projects/cv_v1_clasico.tex` … `cv_v5_dos_columnas.tex`.
   - **Prohibido** usar `~/projects/cv_drb_*` (es el CV de David Rivero) y `~/cv.tex` (plantilla vacía).

`references/analisis-raulartigues.md` describe **qué tipo de información** presenta la web de referencia.
Úsalo solo como checklist de secciones. No copies textos, estilo ni estructura visual.

## Procedimiento
1. Comprueba en `docs/brief.md` qué secciones e idiomas se aprobaron y si los proyectos de MAPFRE
   se pueden publicar con nombre y cifras. Si no consta, **pregunta** (bloque D del banco de preguntas).
2. Genera los textos en `content/` (la estructura la crea `web-scaffold`; si aún no existe, crea solo
   `content/`):
   - `content/site.{es,en}.json`: navegación, hero, sobre mí, CTA, footer, SEO (title ≤ 60 caracteres,
     description ≤ 155).
   - `content/experiencia.{es,en}.json`, `content/formacion.{es,en}.json`, `content/stack.json`.
   - Artículos/proyectos iniciales con `templates/articulo.md` y `templates/proyecto.md`.
3. Redacción:
   - Hero: nombre + rol + una frase de valor (≤ 14 palabras) + 2 CTAs. Ofrece **3 alternativas** de
     frase de valor basadas en las variantes "Sobre mí" del CV y deja elegir.
   - Bio: 60-90 palabras, primera persona (salvo que el brief diga otra cosa).
   - Experiencia: logros con verbo + qué + para qué; cifras solo si están en el perfil y autorizadas.
   - EN: traducción natural, no literal; mantener términos técnicos.
4. Marca cada dato que falte como `"TODO_PREGUNTAR: …"` y al final pregunta todos los TODO en un bloque.
5. Muestra los textos al usuario agrupados por sección y pide aprobación. Itera.

## Puerta de salida
`grep -r TODO_PREGUNTAR content/` vacío, textos aprobados y commit `content: textos iniciales`.

## Errores típicos a evitar
- Mezclar fechas: el CV principal pone *Data & AI Scientist, MAPFRE, feb. 2025 – actualidad*; no inventar
  puestos anteriores.
- Añadir idiomas o certificaciones no listados.
- Inventar testimonios, logos de clientes, "+X años de experiencia" o contadores.
