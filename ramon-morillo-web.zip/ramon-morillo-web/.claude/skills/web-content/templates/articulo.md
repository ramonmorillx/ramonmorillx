---
# Plantilla de artículo (Markdown + frontmatter). Válida tanto para ficheros en content/blog/ como para
# importarla en el panel de administración (el backend acepta el mismo frontmatter).
title: "TODO título (≤ 70 caracteres)"
slug: "todo-titulo-en-kebab-case"
lang: "es"            # es | en
translationOf: ""     # slug del artículo equivalente en el otro idioma, si existe
date: "2026-01-31"
updated: ""
summary: "TODO resumen de 1-2 frases (≤ 160 caracteres), se usa como meta description."
tags: ["mlops", "llm"]
cover: "./cover.webp" # 1600x900, WebP, ≤ 250 KB
coverAlt: "TODO descripción de la imagen"
draft: true
---

## Contexto

Qué problema y por qué importa.

## Enfoque

Arquitectura, decisiones, código.

```python
# bloques de código con lenguaje indicado
```

## Resultados

Solo cifras reales y publicables.

## Lecciones aprendidas
