---
# Plantilla de proyecto personal. Mismo formato en content/proyectos/ y en el panel de administración.
title: "TODO nombre del proyecto"
slug: "todo-nombre"
lang: "es"
date: "2026-01-31"
status: "en-curso"     # idea | en-curso | terminado | archivado
summary: "TODO qué es y qué problema resuelve en una frase."
stack: ["Python", "FastAPI"]
repo: "https://github.com/ramonmorillx/TODO"   # vacío si es privado
demo: ""                                        # URL pública o vacío
article: ""                                     # slug del artículo relacionado
cover: "./cover.webp"
coverAlt: "TODO"
featured: false
draft: true
---

## Qué hace

## Cómo está construido

## Qué aprendí
