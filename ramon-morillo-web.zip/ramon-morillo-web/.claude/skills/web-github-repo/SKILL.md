---
name: web-github-repo
description: Configura git y GitHub para la web de Ramón Morillo - identidad personal (no corporativa), creación del repositorio remoto, ramas, protección de main, convenciones de commits, secretos y plantillas. Úsala en la fase 3, al crear/conectar el remoto, al configurar secretos de GitHub Actions o ante dudas de flujo git.
---

# Fase 3 · Repositorio en GitHub

El repo local ya existe en `~/proyectos/ramon-morillo-web` (rama `main`). Esta skill lo conecta a GitHub.

## 0. Avisos de esta máquina (comprobados)
- La identidad git **global** es la corporativa (`RMORIL3_mapfre`, email @mapfre.com). Para un proyecto
  personal hay que fijar una identidad **local** al repo.
- La config global tiene `http.sslverify=false`: no la copies a CI ni a la documentación del proyecto.
- El home (`~`) es a su vez un repo git: trabaja siempre dentro de `~/proyectos/ramon-morillo-web`
  y comprueba con `git rev-parse --show-toplevel` antes de hacer commit.

## 1. Preguntas (si no constan en `docs/brief.md` → bloque J)
1. Cuenta de GitHub (¿`ramonmorillx`?), nombre del repo (por defecto `ramon-morillo-web`), visibilidad.
2. Nombre y email para los commits. Recomendado: `Ramón Morillo` +
   `<id>+ramonmorillx@users.noreply.github.com` (GitHub > Settings > Emails).
3. ¿Cómo autenticar? (a) `gh auth login` (navegador, recomendado), (b) SSH key personal, (c) token
   fine-grained. El agente **no** debe ver la contraseña ni el token.

## 2. Pasos
```bash
cd ~/proyectos/ramon-morillo-web
git rev-parse --show-toplevel          # debe imprimir esta carpeta
git config user.name  "Ramón Morillo"  # local, NO --global
git config user.email "<email elegido>"
gh auth status || gh auth login        # el usuario completa el login en el navegador
gh repo create ramonmorillx/ramon-morillo-web --public --source=. --remote=origin \
  --description "Web personal de Ramón Morillo: portfolio, blog y proyectos" --push
```
Si `gh` no está: el usuario crea el repo vacío en https://github.com/new (sin README) y luego
`git remote add origin git@github.com:ramonmorillx/ramon-morillo-web.git && git push -u origin main`.

Si se usa la herramienta MCP de GitHub del agente, comprueba antes con `get_me` que la cuenta
autenticada es la personal; si es la corporativa, **detente y pregunta**.

## 3. Configuración del repo (tras el primer push)
- Rama por defecto `main`; trabajo en ramas `feat/…`, `fix/…`, `docs/…` y PR a `main`.
- Protección de `main` (Settings > Branches o `gh api`): requerir PR + checks de CI verdes. Si trabaja
  solo, se puede permitir merge sin review pero con checks.
- Commits: Conventional Commits (`feat:`, `fix:`, `docs:`, `chore:`, `content:`, `ci:`).
- Añadir: `.github/dependabot.yml` (npm `/frontend`, pip `/backend`, docker, github-actions; semanal),
  `.github/PULL_REQUEST_TEMPLATE.md` con checklist (tests, capturas, brief actualizado).
- Activar *secret scanning* y *push protection* (gratis en repos públicos).
- Topics: `portfolio`, `astro`, `fastapi`, `docker`, `ai-engineer`.

## 4. Secretos (los define el usuario; el agente solo lista nombres)
Settings > Secrets and variables > Actions, o `gh secret set NOMBRE` (el usuario pega el valor):
`DEPLOY_HOST`, `DEPLOY_USER`, `DEPLOY_SSH_KEY`, `ADMIN_PASSWORD_HASH`, `SECRET_KEY`, `SMTP_*`/`RESEND_API_KEY`,
`TURNSTILE_SECRET`. Lista definitiva: `web-deploy`.

## Puerta de salida
`git remote -v` apunta al repo personal, `git log -1 --format='%an <%ae>'` muestra la identidad personal,
push hecho. Anotar URL del repo en `docs/estado-proyecto.md`.
