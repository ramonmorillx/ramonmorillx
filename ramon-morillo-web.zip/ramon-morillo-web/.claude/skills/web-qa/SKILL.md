---
name: web-qa
description: Verifica la calidad de la web de Ramón Morillo antes de publicar o tras cambios grandes - tests backend y frontend, e2e con Playwright, Lighthouse (rendimiento, accesibilidad, SEO, buenas prácticas), enlaces rotos, check de la intro de agentes, revisión de contenido y seguridad básica. Úsala en la fase 9, antes de cada release o si el usuario pide "revisa que todo esté bien".
---

# Fase 9 · Calidad

## Checklist (ejecutar todo, reportar como tabla ✅/❌ con la evidencia)
| # | Comprobación | Comando / método | Criterio |
|---|---|---|---|
| 1 | Backend | `cd backend && uv run ruff check . && uv run mypy app && uv run pytest --cov=app` | verde, cobertura ≥ 85 % |
| 2 | Frontend | `cd frontend && npm run lint && npm run build && npm test` | verde |
| 3 | E2E | `cd frontend && npx playwright test` (con `docker compose up` o backend de test) | verde |
| 4 | Intro | `make intro-check` + revisar `compare-*.jpg` | errors 0, pass true |
| 5 | Lighthouse | `npx lighthouse http://localhost/?nointro --preset=desktop --output=json` y móvil | ≥ 90 en las 4 categorías (home, un artículo, contacto) |
| 6 | Accesibilidad | `npx @axe-core/cli http://localhost/?nointro` + navegación con teclado manual | 0 violaciones serias |
| 7 | Enlaces | `npx linkinator http://localhost --recurse --skip "linkedin.com"` | 0 rotos |
| 8 | SEO | `title`/`description` únicos, `hreflang`, `sitemap`, `robots.txt`, OG image, JSON-LD válido | todo presente |
| 9 | Contenido | comparar textos con `../web-content/references/perfil-ramon-morillo.md` y `docs/brief.md` | 0 datos inventados, 0 `TODO` |
| 10 | Seguridad | cabeceras (`curl -sI`), `/docs` desactivado en prod, admin sin sesión → 401, `gitleaks detect` o *secret scanning*, `npm audit --omit=dev`, `uv pip list --outdated` | sin altas/críticas |
| 11 | Responsive | capturas Playwright a 390, 768, 1440, 1920 px | revisadas y aprobadas por el usuario |
| 12 | Docker | `docker compose up --build -d && docker compose ps` | todos healthy |

## Procedimiento
1. Ejecuta la tabla completa; no te detengas en el primer fallo, recoge todos.
2. Arregla lo que sea claramente un bug. Para lo que implique decidir (p. ej. quitar una animación que
   baja el rendimiento, cambiar un texto), **pregunta**.
3. Repite hasta todo ✅ o hasta que el usuario acepte explícitamente una excepción (anotarla en
   `docs/decisiones.md`).

## Puerta de salida
Tabla final toda ✅ (o excepciones aceptadas) guardada en `docs/estado-proyecto.md` con fecha.
