---
name: web-env-setup
description: Prepara y verifica el entorno local (Node.js, Python + uv, Docker, git, gh, Playwright, ffmpeg) para la web de Ramón Morillo, incluyendo el caso de red corporativa con proxy. Úsala en la fase 0, cuando un comando falle por herramienta ausente, o cuando una descarga falle por proxy (403, CONNECT tunnel failed).
---

# Fase 0 · Entorno local

## 1. Diagnóstico (no instala nada todavía)

Ejecuta y muestra el resultado como tabla (herramienta · versión · OK/falta):

```bash
node -v; npm -v; python3 --version; uv --version; docker version --format '{{.Server.Version}}'; \
docker compose version; git --version; gh --version | head -1; ffmpeg -version | head -1
echo "PLAYWRIGHT_PATH=${PLAYWRIGHT_PATH:-<no definido>}"
env | grep -i '_proxy=' | sed 's/:[^:@]*@/:***@/'   # NUNCA imprimir el valor sin enmascarar
```

Versiones objetivo: Node 22 LTS, Python 3.12+, uv ≥ 0.5, Docker Engine 27+ con Compose v2.

Estado conocido de la máquina de Ramón (WSL Ubuntu 24.04, revisado al crear el repo): **Python 3.12 sí**,
**Node no**, **Docker no** (en WSL), **gh no**, proxy corporativo MAPFRE activo. Re-verifícalo siempre.

## 2. Preguntas antes de instalar

1. ¿Trabajas en el portátil corporativo (con proxy) o en un equipo personal? Recomendado: equipo
   personal para un proyecto personal; si es el corporativo, confirma que tu política lo permite.
2. ¿Puedo instalar con `sudo -A` (apt) o prefieres instalaciones solo de usuario (nvm, uv)?
   Recomendado: solo de usuario para Node y uv.
3. Docker: ¿Docker Desktop en Windows con integración WSL, o Docker Engine dentro de WSL?
   Recomendado: Docker Desktop si ya lo tienes en Windows; si no, Engine en WSL.

## 3. Instalación (tras respuesta)

```bash
# Node 22 LTS vía nvm (usuario)
curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash
source ~/.nvm/nvm.sh && nvm install 22 && nvm alias default 22

# uv (gestor Python)
curl -LsSf https://astral.sh/uv/install.sh | sh

# GitHub CLI (requiere sudo)
sudo -A apt-get update && sudo -A apt-get install -y gh

# Docker Engine en WSL (si se eligió) – guía oficial: https://docs.docker.com/engine/install/ubuntu/
# Docker Desktop: instalar en Windows y activar Settings > Resources > WSL integration.
```

Playwright y ffmpeg los instala `web-agent-intro` dentro de `tools/agent-cursors/` cuando haga falta.

## 4. Red corporativa / proxy

- npm: respeta `HTTPS_PROXY`. Si falla por certificados: `npm config set cafile /etc/ssl/certs/ca-certificates.crt`
  (nunca `strict-ssl false`).
- uv/pip: `export SSL_CERT_FILE=/etc/ssl/certs/ca-certificates.crt` o `UV_NATIVE_TLS=1`.
- Docker: el daemon necesita su propio proxy (Docker Desktop: Settings > Resources > Proxies).
- **Sitios bloqueados** (comprobado: `visionpictures.net` devuelve 403 en el proxy MAPFRE): no intentes
  saltarte el proxy. Los scripts de agent-cursors ya están en `tools/agent-cursors/` (aportados por Ramón);
  si hiciera falta otro recurso bloqueado, pide al usuario que lo obtenga desde una red personal.
- Si no hay Node instalado pero sí VS Code Server, su binario sirve para comprobaciones rápidas de sintaxis:
  `$(ls -d ~/.vscode-server/cli/servers/Stable-*/server/node | tail -1) --check fichero.mjs` (no trae npm).

## 5. Puerta de salida

Tabla final con todo en OK, o lista explícita de herramientas que el usuario acepta no tener todavía
(p. ej. Docker se puede posponer hasta la fase 8). Anótalo en `docs/estado-proyecto.md`.
