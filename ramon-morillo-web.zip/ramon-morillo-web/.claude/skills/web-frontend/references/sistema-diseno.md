# Sistema de diseño (propuesta base, confirmar con el usuario)

Inspiración: estética de producto tech actual (no la de la web de referencia). Tres direcciones; la
elegida se fija en `docs/brief.md` y aquí solo se mantienen los tokens finales.

## Dirección A · Dark tech editorial (recomendada)
```css
:root[data-theme="dark"] {
  --bg: #0A0B0F;  --bg-elev: #12141B;  --bg-card: #161924;
  --border: #252A38;  --text: #F2F4F8;  --text-muted: #9AA3B5;
  --accent: #7CFFB2;  /* verde eléctrico; alternativa #8B7CFF violeta, #4DD4FF cian */
  --accent-ink: #04130B;  --glow: color-mix(in oklab, var(--accent) 30%, transparent);
}
:root[data-theme="light"] {
  --bg: #F6F7F9;  --bg-elev: #FFFFFF;  --bg-card: #FFFFFF;
  --border: #E3E6EC;  --text: #0B0D12;  --text-muted: #5A6273;
  --accent: #0F9D58;  --accent-ink: #FFFFFF;
}
```
## Dirección B · Light minimal suizo
Fondo `#F4F1EA`, texto `#111`, acento `#FF4D00`, rejilla de 12 columnas visible en secciones clave.

## Dirección C · Gradiente / glass
Fondo `#0B1020` con malla radial (`#3B82F6`, `#A855F7`, `#22D3EE` al 20 %), tarjetas
`rgba(255,255,255,.06)` + `backdrop-filter: blur(16px)` + borde `rgba(255,255,255,.12)`.

## Tipografía (escala fluida solo en el sitio real; la captura de la intro se hace a 1920 px)
| Token | Uso | Tamaño |
|---|---|---|
| `--fs-display` | h1 hero | `clamp(3rem, 8vw, 8.5rem)`, peso 700, `line-height .92`, `letter-spacing -0.04em` |
| `--fs-h2` | títulos de sección | `clamp(2.25rem, 4.5vw, 5rem)` |
| `--fs-h3` | títulos de tarjeta | `clamp(1.375rem, 2vw, 2rem)` |
| `--fs-body` | cuerpo | `clamp(1.0625rem, 1.2vw, 1.3rem)` |
| `--fs-small` | etiquetas | `0.9375rem` mínimo (nunca < 15 px) |
Familias por defecto: `Geist` (texto) y `Geist Mono` (etiquetas, código, medidas tipo "agente").

## Espaciado, radios, sombras
`--space-1..10` = 4, 8, 12, 16, 24, 32, 48, 64, 96, 128 px · `--radius-sm 10px`, `--radius 18px`,
`--radius-lg 28px`, `--radius-pill 999px` · contenedor `max-width: 1500px; margin-inline: auto; padding-inline: 24px`.

## Componentes clave
- **Hero**: etiqueta pequeña (mono) "AI Engineer · Madrid", h1 ≤ 5 palabras con la palabra clave en
  `<em>` color acento, una frase, 2 botones (primario relleno, secundario borde). A la derecha, composición
  de 3-5 tarjetas superpuestas (proyectos/stack) y detrás una palabra gigante con texto degradado.
- **Tarjeta de proyecto**: imagen 16:10, etiquetas de stack (pills mono), título, resumen, enlaces.
- **Tarjeta de artículo**: fecha + tiempo de lectura (mono), título, resumen, etiquetas.
- **Timeline de experiencia**: proyecto por bloque, logros en lista, stack en pills.
- **Botones**: fondo, borde y radio propios; foco `outline: 2px solid var(--accent); outline-offset: 3px`.

## Movimiento
- Entradas con `opacity`/`translate` ≤ 400 ms, `ease-out`; desactivadas con `prefers-reduced-motion`
  y con `?capture=1` (requisito de la intro).
