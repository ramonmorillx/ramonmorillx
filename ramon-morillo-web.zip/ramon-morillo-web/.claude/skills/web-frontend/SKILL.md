---
name: web-frontend
description: Construye y mantiene el frontend Node.js (Astro + TypeScript) de la web de Ramón Morillo - diseño moderno, páginas (home, proyectos, blog, contacto, admin), i18n ES/EN, consumo de la API FastAPI, SEO, accesibilidad y tests. Úsala en la fase 6 o para cualquier cambio en frontend/.
---

# Fase 6 · Frontend (Astro, Node.js 22)

## Requisitos previos
- Brief aprobado (estilo, secciones, idiomas), textos en `content/` aprobados, `docs/api.md` cerrado.

## 1. Preguntas (si no constan)
1. Confirmar dirección visual, acento HEX y tipografías (bloque E). Presenta **un moodboard en texto**
   (paleta con HEX, tipografías, 3 adjetivos, ejemplo de tarjeta) y pide OK antes de maquetar.
2. ¿Panel de admin dentro de Astro (`/admin`, R) o app separada?
3. ¿Generar imágenes de portada como SVG propios (R) o aportará fotos/capturas reales?

## 2. Diseño
Sigue `references/sistema-diseno.md`. Resumen de reglas no negociables:
- Tokens CSS en `src/styles/tokens.css` (colores, tipografía, espaciado, radios, sombras). Nada de
  colores sueltos en componentes.
- Mobile-first y responsive real (la intro de agentes trabaja con una captura aparte; ver más abajo).
- Contraste AA mínimo, foco visible, navegación por teclado, `prefers-reduced-motion`, `lang` correcto.
- Sin librerías de UI pesadas. JS solo en islas necesarias (menú móvil, selector de tema/idioma,
  formulario, filtros del blog, admin, overlay de intro).

## 3. Páginas
| Ruta | Render | Contenido |
|---|---|---|
| `/` y `/en/` | estático | Hero, sobre mí, logros/especialización, experiencia, proyectos destacados (API en build o SSR), últimos artículos, formación, stack, CTA contacto |
| `/proyectos`, `/proyectos/[slug]` | SSR (`prerender = false`) | lista con filtros por stack/estado; detalle |
| `/blog`, `/blog/[slug]`, `/blog/tag/[tag]` | SSR | lista con filtro por etiqueta, lectura, tiempo de lectura, TOC, compartir |
| `/contacto` | estático + isla | formulario → `POST /api/contact`, estados enviando/éxito/error |
| `/admin/**` | SSR, `noindex` | login, listado y editor Markdown con vista previa, subida de imágenes, mensajes |
| `/rss.xml`, `/sitemap-index.xml`, `/404` | — | RSS por idioma, `@astrojs/sitemap` |

Equivalentes `/en/...` según i18n de Astro (`defaultLocale: 'es'`, `prefixDefaultLocale: false`).

## 4. Datos
- Textos fijos: importar desde `../content/*.json` (alias Vite `@content`). Nunca hardcodear copy en componentes.
- Dinámicos: `src/lib/api.ts` con tipos que reflejan `docs/api.md`; base URL `API_INTERNAL_URL`
  (servidor) y `/api` (navegador). Manejar errores con estados vacíos amables, nunca pantallas rotas.

## 5. Preparar la home para la intro de agentes (importante)
La intro (`web-agent-intro`) congela la home a 1920 px con `capture.mjs`. Para que la captura sea fiel:
- Cada texto en su propio elemento, cada enlace en su propio `<a>`; tarjetas y botones con fondo, borde y
  `border-radius` propios.
- Imágenes con `border-radius` y `object-fit: cover` en el `<img>`, sin `overflow:hidden` alrededor; sin
  `transform` en imágenes o textos (envolver en `<div>` si hay que rotar).
- Las animaciones de scroll deben quedar en su estado final si `?capture=1` está en la URL o
  `prefers-reduced-motion` está activo.
- Añade `data-intro-root` al contenedor principal de la home.

## 6. SEO y rendimiento
- `<title>`, meta description, canonical, `hreflang` es/en, Open Graph + Twitter card (`og-default.png`
  1200×630), JSON-LD `Person` (nombre, jobTitle, sameAs GitHub/LinkedIn) y `BlogPosting` en artículos.
- Imágenes con `astro:assets` (AVIF/WebP, `width/height`, `loading="lazy"` salvo hero), fuentes
  autoalojadas con `font-display: swap` y preload de la principal.
- Objetivo Lighthouse ≥ 90 en todo (lo verifica `web-qa`).

## 7. Tests
- `vitest`: utilidades (i18n, formateo de fechas, cliente API con fetch mockeado).
- Playwright e2e (`tests/e2e`): navegación principal, cambio de idioma, filtro del blog, envío de
  contacto (API mockeada con `page.route`), login admin contra backend de test, "Saltar intro".

## Puerta de salida
`npm run lint && npm run build && npm test` verdes; todas las rutas del brief existen; revisión visual en
1440 px y 390 px (capturas con Playwright en `frontend/test-results/visual/`) mostradas al usuario y aprobadas.
