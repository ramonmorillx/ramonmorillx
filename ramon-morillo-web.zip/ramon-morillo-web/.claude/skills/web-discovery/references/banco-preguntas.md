# Banco de preguntas (fase de descubrimiento)

Formato de cada pregunta: opciones · **(R)** = recomendada y por qué.

## A. Objetivo y público
1. Objetivo principal: (a) conseguir ofertas de empleo, (b) captar proyectos freelance/consultoría,
   (c) marca personal / divulgación, (d) mezcla. **(R) d con prioridad a**: tu CV apunta a perfil AI Engineer.
2. Público: reclutadores, CTOs/managers técnicos, universidades/eventos, comunidad técnica. ¿Orden de prioridad?
3. Acción principal que debe hacer un visitante (CTA): contactar por formulario, descargar CV, abrir LinkedIn,
   agendar llamada. **(R) contactar + descargar CV**.
4. ¿Mencionar que estás abierto a nuevas oportunidades? (sí / no / solo freelance).

## B. Idiomas y tono
1. Idiomas: (a) solo ES, (b) ES + EN con selector, (c) solo EN. **(R) b**: la referencia es bilingüe y
   las empresas tech leen en inglés.
2. Tono: profesional cercano / técnico / ejecutivo. **(R) profesional cercano** (como las variantes de tu CV).
3. ¿Tratamiento en primera persona ("Diseño…") o tercera ("Ramón diseña…")? **(R) primera**.

## C. Secciones (inspiradas en la estructura de contenido de raulartigues.com, no en su estilo)
Marca cuáles quieres:
- Hero (nombre, rol, frase de valor, CTAs) · Sobre mí · Experiencia · Proyectos destacados (casos de
  trabajo) · Proyectos personales · Blog técnico · Publicaciones / TFM · Ponencias y docencia ·
  Formación · Stack / habilidades · Logros clave · Contacto · Descarga de CV (PDF).
- ¿Asistente IA que responde preguntas sobre tu perfil (como el chat de la referencia)? Coste de API y
  riesgo de respuestas inventadas. **(R) no en la v1**, dejarlo como mejora futura.

## D. Contenido sensible
1. ¿Puedo publicar los nombres internos de proyectos de MAPFRE (Fraud Auto, Fraud Graph, Document AI,
   Asistente CGU, Vehicle Vision) y sus métricas (175 subcategorías, 687 documentos, 5 niveles de riesgo)?
   (a) sí tal cual, (b) genéricos sin nombres internos ni cifras, (c) consultaré a MAPFRE. **(R) c → b mientras tanto**.
2. Teléfono: publicar / no. **(R) no** (spam). Email: ¿`ramonvejer@gmail.com` u otro? ¿Mostrarlo o solo formulario?
3. Foto: ¿tienes una foto profesional? Ruta del fichero. Si no, la web se diseña sin foto.
4. ¿Qué CV en PDF se ofrece para descargar (ES/EN)? ¿De qué variante (`cv.tex`, `cv_v1`…`cv_v5`)?
5. Idiomas que hablas y nivel (tu CV solo lista "Español (nativo)"): ¿inglés? ¿nivel?
6. Ubicación: ¿"Madrid, España"? ¿Disponibilidad remoto/híbrido?

## E. Estilo visual (moderno; NO copiar el estilo de la referencia)
1. Dirección: (a) *Dark tech editorial* (fondo casi negro, tipografía grande, acento eléctrico),
   (b) *Light minimal suizo* (blanco roto, rejilla estricta, un acento fuerte), (c) *Gradiente/glass*
   (fondos con malla de color, tarjetas translúcidas), (d) otra (describe o pasa URLs que te gusten).
   **(R) a**: encaja con IA/ingeniería y hace lucir la intro de agentes.
2. Color de acento (afecta también a `data-accent` de la intro): propuesta según dirección o HEX propio.
3. Tipografías: (a) Inter + JetBrains Mono, (b) Space Grotesk + Inter, (c) Geist + Geist Mono. **(R) c**.
4. Modo claro/oscuro: solo uno / ambos con selector. **(R) ambos**, oscuro por defecto.
5. Micro-animaciones al hacer scroll: sí / no. **(R) sí, sutiles y respetando `prefers-reduced-motion`**.

## F. Blog y proyectos personales
1. ¿Cómo quieres subir artículos y proyectos?
   (a) **Panel de administración** propio (backend Python) con editor Markdown y subida de imágenes,
   (b) **Ficheros Markdown en el repo** (publicar = hacer commit), (c) ambos.
   **(R) a**: lo pediste explícitamente ("poder subir"), y el backend Python lo justifica.
2. Formato de artículos: Markdown / MDX / editor visual. **(R) Markdown** con bloques de código y fórmulas.
3. ¿Categorías/etiquetas y filtros? ¿Búsqueda? ¿Tiempo de lectura? ¿RSS? **(R) etiquetas + filtro + RSS**.
4. ¿Comentarios? (no / Giscus con GitHub Discussions). **(R) no en v1**.
5. Proyectos personales: ¿qué campos? (título, resumen, stack, enlace GitHub, demo, imagen, fecha, estado).
6. ¿Tienes ya artículos o proyectos para cargar al inicio? Pásalos o di dónde están.

## G. Contacto
1. Formulario: nombre, email, asunto, mensaje. ¿Algo más (empresa, presupuesto)?
2. ¿A dónde llegan los mensajes? (a) email vía SMTP/servicio (Resend, Brevo…), (b) solo guardados en BD y
   vistos en el panel, (c) ambos. **(R) c**.
3. Anti-spam: honeypot + rate limit (gratis) / Cloudflare Turnstile. **(R) honeypot + rate limit + Turnstile**.

## H. Intro con agentes (agent cursors) · ver `web-agent-intro/references/integracion.md`
1. ¿Cuándo se reproduce? (a) cada visita, (b) primera visita de la sesión, (c) solo la primera visita.
   **(R) b**, con botón "Saltar intro" siempre visible.
2. ¿En qué páginas? **(R) solo en la home**.
3. Duración objetivo de la intro: **(R) 15-25 s**. Se ajusta con `tempo` cuando se conozca la duración real
   (`render.mjs --check`). Si ni a doble velocidad cabe, ¿intro solo de cabecera + hero?
4. ¿Mostrar la barra de navegador simulada (pestañas "Agents · N running", dirección con tu dominio)?
   **(R) oculta en la web, visible en los MP4**.
5. En móvil: (a) vertical en vivo "N AI agents. One website. Live." escalado (sin descarga de vídeo),
   (b) MP4 9:16 comprimido, (c) sin intro. **(R) a**.
6. ¿Generar también los MP4 16:9 (4K) y 9:16 para LinkedIn? **(R) sí**.
7. Licencia: `agents.js` dice "Free from visionpictures.net". ¿Has revisado en su web que permite uso en una
   web pública? (el agente no puede aceptar términos por ti).

## I. Técnica (proponer defaults, confirmar)
1. Frontend: (a) **Astro** (Node.js, contenido primero, casi sin JS, i18n, MDX), (b) Next.js (React,
   más pesado), (c) SvelteKit. **(R) a**.
2. Backend: **FastAPI** (Python 3.12, uv, SQLModel, Alembic). ¿OK?
3. Base de datos: (a) SQLite en volumen (simple, 1 usuario admin), (b) PostgreSQL. **(R) b** si habrá
   panel + mensajes; a si se quiere mínimo coste.
4. Imágenes subidas: disco en volumen / S3-compatible (Cloudflare R2). **(R) volumen** en v1.
5. Analítica: ninguna / Plausible / Umami autoalojado / Google Analytics (requiere banner cookies).
   **(R) Umami o Plausible** (sin cookies).

## J. Publicación
1. Dominio: ¿tienes uno? ¿Cuál quieres (p. ej. `ramonmorillo.com`/`.dev`/`.es`)? ¿Registrador?
2. Hosting: (a) VPS (Hetzner/DigitalOcean, ~5 €/mes) con Docker Compose + Caddy, (b) PaaS (Render,
   Railway, Fly.io), (c) frontend estático en Cloudflare Pages + backend en PaaS. **(R) a**: todo el stack
   dockerizado tal cual, control total, coste fijo bajo.
3. Presupuesto mensual máximo.
4. Cuenta de GitHub para el repo (personal `ramonmorillx`?) y visibilidad (pública/privada).
   **(R) pública**: sirve de portfolio, sin secretos en el repo.
5. Email/identidad git para los commits (no usar la corporativa). **(R) email noreply de GitHub**.
