# Brief · Web de Ramón Morillo

> Estado: BORRADOR | APROBADO (fecha) — Fuente de cada dato: respuesta del usuario (fecha) o CV.

## 1. Objetivo y público
- Objetivo principal: TODO
- Público por prioridad: TODO
- CTA principal / secundaria: TODO
- Abierto a oportunidades: TODO

## 2. Idiomas y tono
- Idiomas: TODO
- Tono / persona gramatical: TODO

## 3. Mapa del sitio
| Página / sección | Ruta | Incluida | Notas |
|---|---|---|---|
| Home (hero + resumen) | `/` | TODO | |
| Sobre mí | `/#sobre-mi` o `/sobre-mi` | TODO | |
| Experiencia | | TODO | |
| Proyectos | `/proyectos` | TODO | |
| Blog | `/blog` | TODO | |
| Formación | | TODO | |
| Stack | | TODO | |
| Contacto | `/contacto` | TODO | |
| Admin | `/admin` | TODO | protegido |

## 4. Contenido sensible
- Proyectos MAPFRE: TODO (tal cual / genéricos / pendiente)
- Email público: TODO · Teléfono: TODO · Foto: TODO (ruta)
- CV descargable: TODO (variante, idiomas)
- Idiomas hablados: TODO · Ubicación/modalidad: TODO

## 5. Estilo visual
- Dirección: TODO · Acento HEX: TODO · Tipografías: TODO
- Claro/oscuro: TODO · Animaciones: TODO
- Referencias visuales aportadas: TODO

## 6. Blog y proyectos
- Mecanismo de publicación: TODO (panel / markdown / ambos)
- Campos de artículo: TODO · Campos de proyecto: TODO
- Etiquetas/filtros/RSS/búsqueda/comentarios: TODO
- Contenido inicial: TODO

## 7. Contacto
- Campos: TODO · Destino: TODO · Anti-spam: TODO

## 8. Intro con agentes
- Cuándo: TODO · Páginas: TODO · Duración objetivo / tempo: TODO · Alcance (home completa / hero): TODO
- Barra de navegador simulada: TODO · Móvil (reel / video / none): TODO · MP4 para redes: TODO
- Licencia revisada por el usuario: TODO

## 9. Técnica
- Frontend: TODO · Backend: TODO · BD: TODO · Almacenamiento imágenes: TODO · Analítica: TODO

## 10. Publicación
- Dominio: TODO · Hosting: TODO · Presupuesto: TODO
- Cuenta GitHub / visibilidad: TODO · Identidad git: TODO
