---
name: web-discovery
description: Fase de descubrimiento de requisitos de la web personal de Ramón Morillo. Hace al usuario todas las preguntas necesarias (objetivo, público, idiomas, secciones, estilo visual, blog, proyectos, contacto, intro con agentes, hosting, dominio, presupuesto, privacidad) y produce docs/brief.md aprobado. Úsala antes de escribir cualquier código o cuando un requisito no esté claro.
---

# Fase 1 · Descubrimiento

Objetivo: un `docs/brief.md` completo y aprobado. **No se escribe código en esta fase.**

## Procedimiento

1. Lee `references/banco-preguntas.md` y `docs/brief.md` (si existe) para no repetir preguntas.
2. Lee el análisis de la web de referencia: `../web-content/references/analisis-raulartigues.md`
   y el perfil: `../web-content/references/perfil-ramon-morillo.md`.
3. Haz las preguntas **por bloques temáticos** (A → J), un bloque por turno, cada pregunta con
   opciones y una recomendada. Espera la respuesta antes de pasar al siguiente bloque.
4. Tras cada bloque, actualiza `docs/brief.md` usando `templates/brief.md`.
5. Al final, muestra el brief completo y pide aprobación explícita ("¿Apruebas el brief? sí/cambios").
6. Registra decisiones técnicas en `docs/decisiones.md` (formato: `## ADR-00N Título` · Contexto ·
   Decisión · Alternativas · Consecuencias).

## Reglas

- Máximo ~6 preguntas por bloque. Si una respuesta abre dudas nuevas, pregúntalas en el siguiente turno.
- Si el usuario responde "lo que tú veas", aplica la recomendada y anótala como "por defecto".
- Si una respuesta contradice algo anterior, señálalo y pide que elija.
- Las preguntas sobre datos personales (teléfono, foto, email) siempre con la opción "no publicar".

## Puerta de salida

`docs/brief.md` sin campos `TODO`, aprobado por el usuario, y commit `docs: brief aprobado`.
