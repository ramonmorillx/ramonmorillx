---
name: web-content-publishing
description: Uso diario de la web de Ramón Morillo ya construida - publicar o editar un artículo del blog o un proyecto personal (vía panel /admin o Markdown), traducirlo ES/EN, preparar imágenes, actualizar experiencia/CV y regenerar la intro de agentes si cambia la home. Úsala cuando el usuario diga "quiero publicar un artículo", "añade este proyecto", "actualiza mi experiencia" o similar.
---

# Día a día · Publicar contenido

## 1. Preguntas iniciales (siempre)
1. ¿Qué publicamos? artículo / proyecto / cambio de experiencia o datos personales.
2. ¿Tienes el texto (fichero, enlace, borrador en el chat) o lo redactamos juntos a partir de notas?
3. Idiomas: ¿ES, EN o ambos? (si ambos, ¿traduzco yo y lo revisas?)
4. ¿Publicar ya o dejar como borrador?
5. Imágenes: ¿aportas portada o genero una ilustración SVG propia con los colores de la web?

## 2. Artículo o proyecto
1. Parte de `../web-content/templates/articulo.md` o `proyecto.md`. Rellena el frontmatter completo;
   `slug` en kebab-case sin tildes.
2. Revisión: no inventar cifras ni resultados; si el contenido habla de trabajo en MAPFRE, recuerda la
   regla de confidencialidad de `AGENTS.md` y pregunta.
3. Imagen de portada: 1600×900, WebP, ≤ 250 KB (`npx sharp-cli -i in.png -o cover.webp resize 1600 900`),
   `coverAlt` descriptivo.
4. Publicar según el mecanismo del brief:
   - **Panel**: el usuario entra en `https://<dominio>/admin`, "Nuevo artículo", pega el Markdown, sube la
     portada, marca/desmarca borrador y guarda. El agente puede guiarle paso a paso.
   - **API (agente)**: solo si el usuario da una sesión válida en un entorno seguro; nunca pedir la contraseña en el chat.
   - **Markdown en el repo**: crear `content/blog/<slug>/index.md` (+ imágenes) en una rama `content/<slug>`,
     `make seed` en local para previsualizar, PR → merge → el deploy lo publica.
5. Verificar en producción: la URL responde 200, aparece en `/blog` (o `/proyectos`), en el RSS y con la
   tarjeta OG correcta (https://www.opengraph.xyz o similar).

## 3. Cambios en experiencia, formación o datos personales
1. Actualiza primero `../web-content/references/perfil-ramon-morillo.md` (fuente de verdad) indicando la
   fuente (nuevo CV, mensaje del usuario y fecha).
2. Después `content/*.json` (ES y EN), y el PDF del CV en `frontend/public/cv/` si cambia.
3. Si cambia algo visible en la home → `make intro-capture && make intro-check` (skill `web-agent-intro`)
   para que la intro siga siendo 1:1. Si se quiere, regenerar los MP4.
4. PR, CI verde, merge, comprobar en producción.

## 4. Difusión (opcional, preguntar)
Proponer un post de LinkedIn de ≤ 1.300 caracteres con el enlace y, para hitos grandes, adjuntar
`agents-16x9.mp4` o `agents-9x16.mp4`.
