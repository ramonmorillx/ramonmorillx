---
name: web-scaffold
description: Crea la estructura de carpetas y ficheros base del monorepo de la web de Ramón Morillo (frontend Astro/Node.js, backend FastAPI/Python, contenido, herramientas de la intro de agentes, Docker, CI, docs, Makefile). Úsala en la fase 4 o si hay que añadir/reorganizar carpetas de primer nivel.
---

# Fase 4 · Estructura del proyecto

## Requisitos previos
- `docs/brief.md` aprobado (stack confirmado en el bloque I). Si el brief eligió algo distinto a
  Astro/FastAPI/PostgreSQL, adapta el árbol y anótalo en `docs/decisiones.md`.
- `node`, `npm`, `uv` disponibles (fase 0).

## 1. Preguntas
1. ¿Creo los proyectos con los generadores oficiales (`npm create astro@latest`, `uv init`)? (R) sí:
   así quedan las versiones actuales. Alternativa: escribir los ficheros a mano.
2. ¿Gestor de paquetes frontend? npm (R) / pnpm.

## 2. Árbol objetivo
Ver `references/estructura.md` (árbol completo con la responsabilidad de cada carpeta). Créalo así:

```bash
cd ~/proyectos/ramon-morillo-web
mkdir -p docs content/{blog,proyectos} tools/agent-cursors infra/caddy .github/workflows

# Frontend (Astro, TypeScript estricto, sin plantilla de ejemplo)
npm create astro@latest frontend -- --template minimal --typescript strict --install --no-git --skip-houston
cd frontend && npx astro add node --yes && npm i -D vitest @playwright/test prettier prettier-plugin-astro eslint && cd ..

# Backend (FastAPI)
uv init --app --python 3.12 backend
cd backend && uv add "fastapi[standard]" sqlmodel alembic "psycopg[binary]" pydantic-settings \
  argon2-cffi python-multipart markdown-it-py bleach itsdangerous slowapi \
  && uv add --dev pytest pytest-cov httpx ruff mypy && cd ..
```
Después crea los ficheros base que indica `references/estructura.md` (Makefile, `.editorconfig`,
`.gitignore`, `.env.example`, `docs/*.md`) y los esqueletos mínimos (`backend/app/main.py` con
`/api/health`, una página `frontend/src/pages/index.astro` vacía con el layout).

## 3. Makefile (contrato de comandos para humanos y agentes)
Objetivos obligatorios: `help`, `setup`, `dev` (back+front), `dev-backend`, `dev-frontend`, `lint`,
`test`, `build`, `up`, `down`, `logs`, `intro-capture`, `intro-check`, `intro-render`, `seed`.
`make help` debe listar cada objetivo con una línea de descripción (`## comentario` tras el objetivo).

Recetas de la intro (los scripts ya están en `tools/agent-cursors/`; ver `web-agent-intro`):
```make
INTRO_URL   ?= http://localhost:4321/?capture=1
# INTRO_LABEL: dominio final cuando exista, p. ej. ramonmorillo.dev
INTRO_LABEL ?= localhost
intro-capture: ## Congela la home (requiere `npm run preview` en :4321) y la copia a frontend/public/intro
	cd tools/agent-cursors && node capture.mjs "$(INTRO_URL)" --label=$(INTRO_LABEL)
	rm -rf frontend/public/intro && mkdir -p frontend/public/intro
	cp -r tools/agent-cursors/index.html tools/agent-cursors/agents.js tools/agent-cursors/assets frontend/public/intro/
intro-check: ## Comprueba la build de agentes contra el original (errors 0, deviation.pass)
	cd tools/agent-cursors && node render.mjs --check
intro-render: ## Renderiza los MP4 16:9 y 9:16 en segundo plano (logs en tools/agent-cursors/out/)
	cd tools/agent-cursors && mkdir -p out && (nohup node render.mjs > out/16x9.log 2>&1 &) && (nohup node render.mjs --vertical > out/9x16.log 2>&1 &)
```

## 4. `.gitignore` mínimo
`node_modules/ dist/ .astro/ .venv/ __pycache__/ .pytest_cache/ .ruff_cache/ .env *.db data/
tools/agent-cursors/out/ tools/agent-cursors/node_modules/ playwright-report/ test-results/ coverage/`

## Puerta de salida
`make help` funciona, `cd backend && uv run python -c "import app"` funciona, `cd frontend && npm run build`
funciona, y commit `chore: estructura inicial del monorepo`.
