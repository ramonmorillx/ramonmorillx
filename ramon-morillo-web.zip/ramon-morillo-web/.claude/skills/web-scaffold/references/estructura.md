# Estructura del monorepo

```
ramon-morillo-web/
├── AGENTS.md                    # reglas globales para agentes (no borrar)
├── README.md                    # qué es, cómo arrancar, cómo usar las skills
├── Makefile                     # contrato de comandos (make help)
├── .editorconfig  .gitignore  .env.example
├── docker-compose.yml           # desarrollo/local completo (web-docker)
├── docker-compose.prod.yml      # overrides de producción (web-docker / web-deploy)
├── .github/
│   ├── skills/                  # ESTAS skills
│   ├── copilot-instructions.md  # apunta a AGENTS.md
│   ├── workflows/ci.yml         # lint + tests + build + check intro (web-qa)
│   ├── workflows/deploy.yml     # build imágenes → GHCR → despliegue (web-deploy)
│   ├── dependabot.yml
│   └── PULL_REQUEST_TEMPLATE.md
├── docs/
│   ├── brief.md                 # requisitos aprobados (web-discovery)
│   ├── decisiones.md            # ADRs cortos
│   ├── estado-proyecto.md       # fases y verificación (web-orchestrator)
│   ├── api.md                   # contrato de la API (web-backend)
│   └── despliegue.md            # runbook de producción (web-deploy)
├── content/                     # textos y contenido semilla, fuente única de verdad del copy
│   ├── site.es.json  site.en.json
│   ├── experiencia.es.json  experiencia.en.json  formacion.*.json  stack.json
│   ├── blog/<slug>/index.md (+ imágenes)
│   └── proyectos/<slug>/index.md (+ imágenes)
├── frontend/                    # Astro (Node.js 22)
│   ├── astro.config.mjs         # adapter node (standalone), i18n es/en, site URL
│   ├── src/
│   │   ├── layouts/BaseLayout.astro
│   │   ├── components/          # Header, Footer, Hero, ProjectCard, ArticleCard, ContactForm, IntroOverlay…
│   │   ├── pages/               # index, proyectos/, blog/, contacto, admin/, [lang]/…, rss.xml.ts, 404
│   │   ├── styles/tokens.css global.css
│   │   ├── i18n/                # utilidades de idioma; textos vienen de /content
│   │   └── lib/api.ts           # cliente tipado del backend
│   ├── public/
│   │   ├── intro/               # captura congelada de la home + agents.js (web-agent-intro, generado)
│   │   ├── video/               # agents-9x16.mp4 para la intro móvil (generado)
│   │   ├── cv/                  # PDFs del CV
│   │   └── favicon.svg  og-default.png  robots.txt
│   └── tests/                   # vitest (unit) y e2e/ (playwright)
├── backend/                     # FastAPI (Python 3.12, uv)
│   ├── pyproject.toml  uv.lock
│   ├── app/
│   │   ├── main.py              # crea la app, CORS, routers, /api/health
│   │   ├── core/config.py       # pydantic-settings (lee .env)
│   │   ├── core/security.py     # hash argon2, sesión firmada, CSRF/Origin
│   │   ├── db.py                # engine SQLModel, sesión
│   │   ├── models/              # Article, Project, Message, Upload
│   │   ├── schemas/             # entrada/salida pydantic
│   │   ├── api/routes/          # public_articles, public_projects, contact, admin_*, auth, uploads
│   │   └── services/            # markdown→html saneado, email, slug, rss
│   ├── alembic/  alembic.ini    # migraciones
│   ├── scripts/seed.py          # importa content/blog y content/proyectos
│   └── tests/
├── tools/
│   └── agent-cursors/           # YA EXISTE en el repo
│       ├── agents.js            # motor de la intro (no modificar)
│       ├── render.mjs           # check + MP4 (no modificar)
│       ├── capture.mjs          # congela la home a 1920 px (+ flag local --label)
│       ├── SOURCE.md            # origen, sha256, licencia, revisión de seguridad, cambios locales
│       ├── package.json         # (fase 7) playwright + ffmpeg-static
│       ├── index.html assets/   # (ignorado) captura de trabajo; la publicada va a frontend/public/intro/
│       └── out/                 # (ignorado) original/, check/, MP4, logs
└── infra/
    └── caddy/Caddyfile          # proxy inverso + HTTPS automático
```

## Flujo de peticiones (producción)
```
Navegador ──HTTPS──► Caddy ─┬─ /api/*     ─► backend:8000 (FastAPI)
                            ├─ /uploads/* ─► volumen uploads (estático)
                            └─ /*         ─► frontend:4321 (Astro SSR/estático)
Astro SSR ── http://backend:8000 (red interna) para blog/proyectos
FastAPI ─► PostgreSQL (volumen) · SMTP/Resend para avisos de contacto
```
