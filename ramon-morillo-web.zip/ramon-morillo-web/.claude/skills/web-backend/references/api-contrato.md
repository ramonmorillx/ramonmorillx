# Contrato de API (base para docs/api.md)

Prefijo `/api`. JSON UTF-8. Fechas ISO 8601. Errores: `{"detail": "mensaje"}` con código HTTP adecuado.

## Público
| Método | Ruta | Descripción |
|---|---|---|
| GET | `/api/health` | `{"status":"ok","version":"x.y.z"}` |
| GET | `/api/articles?lang=es&tag=mlops&page=1&size=10` | `{items:[ArticleSummary], total, page, size}` |
| GET | `/api/articles/{slug}?lang=es` | `ArticleDetail` (404 si draft o no existe) |
| GET | `/api/projects?lang=es&featured=true` | `{items:[ProjectSummary], total, page, size}` |
| GET | `/api/projects/{slug}?lang=es` | `ProjectDetail` |
| GET | `/api/tags?lang=es` | `[{name, count}]` |
| POST | `/api/contact` | body `ContactIn` → `202 {"ok":true}`; 422 validación; 429 rate limit |

## Admin (cookie de sesión obligatoria; 401 si no)
| Método | Ruta | Descripción |
|---|---|---|
| POST | `/api/auth/login` | `{username,password}` → 204 + cookie |
| POST | `/api/auth/logout` | 204 |
| GET | `/api/auth/me` | `{username}` |
| GET/POST | `/api/admin/articles` | listar (incluye drafts) / crear |
| GET/PUT/DELETE | `/api/admin/articles/{id}` | ver / actualizar / borrar |
| GET/POST | `/api/admin/projects` | ídem |
| GET/PUT/DELETE | `/api/admin/projects/{id}` | ídem |
| POST | `/api/admin/uploads` | multipart `file` → `{url:"/uploads/<uuid>.webp", width, height}` |
| GET | `/api/admin/messages?unread=true` | mensajes de contacto |
| PATCH | `/api/admin/messages/{id}` | `{read:true}` |

## Esquemas
```
ArticleSummary  { slug, lang, title, summary, tags[], cover, coverAlt, date, readingMinutes }
ArticleDetail   ArticleSummary + { html, updated, translationOf }
ArticleIn       { slug, lang, title, summary, tags[], cover, coverAlt, date, markdown, draft, translationOf }
ProjectSummary  { slug, lang, title, summary, stack[], status, repo, demo, cover, coverAlt, featured, date }
ProjectDetail   ProjectSummary + { html, article }
ProjectIn       ProjectSummary sin derivados + { markdown, draft }
ContactIn       { name(2-80), email(EmailStr), subject(2-120), message(10-5000), website(honeypot, debe ir vacío), turnstileToken? }
```

## Reglas
- `slug` único por `lang`; regex `^[a-z0-9]+(?:-[a-z0-9]+)*$`.
- CORS solo para `ALLOWED_ORIGINS` (en prod, mismo dominio vía Caddy → CORS innecesario).
- Cabeceras de caché: público `Cache-Control: public, max-age=60`; admin `no-store`.
