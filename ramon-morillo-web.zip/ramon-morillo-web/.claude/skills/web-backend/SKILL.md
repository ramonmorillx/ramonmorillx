---
name: web-backend
description: Construye y mantiene el backend Python (FastAPI + SQLModel + Alembic, gestionado con uv) de la web de Ramón Morillo - API pública de artículos y proyectos, formulario de contacto, panel de administración autenticado, subida de imágenes, RSS y tests. Úsala en la fase 5 o para cualquier cambio en backend/.
---

# Fase 5 · Backend Python (FastAPI)

## Requisitos previos
- Estructura creada (`web-scaffold`). Brief con decisiones de BD, publicación y contacto (bloques F, G, I).

## 1. Preguntas (solo si no constan en el brief/decisiones)
1. BD: PostgreSQL (R) o SQLite.
2. Contacto: ¿envío de email? Proveedor (Resend (R), Brevo, SMTP de Gmail con contraseña de aplicación).
3. ¿Usuario admin único (R) o varios?
4. Límite de tamaño de imagen subida (R: 5 MB; jpg/png/webp/svg→ svg solo si se sanea o se descarta).
5. ¿Los artículos admiten HTML embebido? (R: no; Markdown saneado).

## 2. Contrato de API
Escribe/actualiza `docs/api.md` a partir de `references/api-contrato.md` **antes** de programar; el
frontend depende de él. Cualquier cambio de contrato → actualizar el doc y avisar.

## 3. Implementación (orden)
1. `core/config.py` con pydantic-settings: `DATABASE_URL`, `SECRET_KEY`, `ADMIN_USER`,
   `ADMIN_PASSWORD_HASH`, `ALLOWED_ORIGINS`, `UPLOADS_DIR`, `PUBLIC_BASE_URL`, `MAIL_*`, `TURNSTILE_SECRET`.
   Todos con validación; la app no arranca si falta un secreto en producción (`ENV=production`).
2. `db.py` + modelos SQLModel: `Article`, `Project`, `Tag` (N:M), `ContactMessage`, `Upload`.
   Campos según `../web-content/templates/articulo.md` y `proyecto.md`.
3. Alembic: `uv run alembic init alembic`, configurar `target_metadata = SQLModel.metadata`, primera
   migración autogenerada y revisada a mano.
4. Rutas públicas (solo `published`/no `draft`), paginación `?page=&size=` (máx. 50), filtro `?tag=&lang=`.
5. Contacto: validación, honeypot (`website` vacío), rate limit (slowapi, 5/h por IP), Turnstile si está
   configurado, guardar en BD y enviar aviso por email en background task.
6. Auth admin: login con argon2 contra `ADMIN_PASSWORD_HASH`; cookie de sesión firmada
   (`HttpOnly; Secure; SameSite=Strict`), expiración 12 h; comprobación de `Origin` en métodos no-GET;
   rate limit de login 5/15 min.
7. Admin CRUD de artículos/proyectos, listado de mensajes, subida de imágenes (validar tipo real con
   cabecera mágica, renombrar a UUID, convertir a WebP si Pillow está disponible, guardar en `UPLOADS_DIR`).
8. Markdown → HTML con `markdown-it-py` + `bleach` (lista blanca), cálculo de tiempo de lectura.
9. `/api/rss.xml` (o en el frontend) y `/api/sitemap-data`.
10. `scripts/seed.py`: importa `content/blog/*/index.md` y `content/proyectos/*/index.md` (idempotente por slug).
11. Generar hash de contraseña para el usuario (él la teclea; el agente no la ve):
    `uv run python -c "from argon2 import PasswordHasher;import getpass;print(PasswordHasher().hash(getpass.getpass()))"`

## 4. Calidad
- `uv run ruff check . && uv run ruff format --check . && uv run mypy app`
- `uv run pytest --cov=app --cov-report=term-missing` (objetivo ≥ 85 %). Tests con BD SQLite temporal y
  `TestClient`: health, listado/filtrado, drafts ocultos, login correcto/incorrecto, CRUD protegido (401 sin
  sesión), subida inválida rechazada, contacto con honeypot rechazado, rate limit.
- Nunca loguear contraseñas, cookies ni el cuerpo de mensajes completos.

## Puerta de salida
Tests y linters verdes, `uv run fastapi dev app/main.py` → `curl localhost:8000/api/health` = `{"status":"ok"}`,
`/docs` (OpenAPI) accesible en desarrollo y **desactivado en producción**. Commit `feat(backend): …`.
