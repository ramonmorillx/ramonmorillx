# ramon-morillo-web

Web personal de **Ramón Morillo** (AI Engineer): carta de presentación para empresas, blog de artículos y
proyectos personales, con una intro en la que agentes-cursor construyen la web en directo.

> Estado: **solo skills**. Todavía no hay código: lo generan los agentes siguiendo las skills, fase a fase,
> preguntándote antes de decidir.

## Qué hay en el repo

```
AGENTS.md                      reglas para cualquier agente (preguntar antes de asumir, no inventar datos…)
tools/agent-cursors/           agents.js, render.mjs, capture.mjs + SOURCE.md (origen, hashes, API, cambios)
.github/copilot-instructions.md  hace que Copilot lea AGENTS.md
.github/skills/                las 13 skills
.claude/skills → .github/skills   las mismas skills para Claude Code (enlace simbólico)
```

| Skill | Para qué | Fase |
|---|---|---|
| `web-orchestrator` | **Punto de entrada.** Lleva el estado, decide la fase, verifica cada puerta | todas |
| `web-env-setup` | Node, Python/uv, Docker, gh; proxy corporativo | 0 |
| `web-discovery` | Te hace todas las preguntas y escribe `docs/brief.md` | 1 |
| `web-content` | Textos ES/EN a partir de tus CVs (perfil verificado incluido) | 2 |
| `web-github-repo` | Identidad git personal, repo remoto, ramas, secretos | 3 |
| `web-scaffold` | Estructura de carpetas del monorepo + Makefile | 4 |
| `web-backend` | API FastAPI: blog, proyectos, contacto, panel admin, subidas | 5 |
| `web-frontend` | Astro (Node.js): diseño moderno, páginas, i18n, SEO, tests | 6 |
| `web-agent-intro` | Intro de agentes construyendo la web + MP4 16:9 y 9:16 | 7 |
| `web-docker` | Dockerfiles, compose, Caddy (HTTPS) | 8 |
| `web-qa` | Tests, e2e, Lighthouse, accesibilidad, enlaces, seguridad | 9 |
| `web-deploy` | VPS, dominio, DNS, GitHub Actions → GHCR → SSH, backups | 10 |
| `web-content-publishing` | Día a día: publicar artículos y proyectos | después |

## Cómo usar las skills

### 1. Abre el proyecto
```bash
cd ~/proyectos/ramon-morillo-web
code .                # VS Code (Copilot Chat en modo Agent)
# o bien: copilot     # GitHub Copilot CLI   ·   claude   # Claude Code
```
Copilot y Claude Code detectan solos las skills de `.github/skills/` (y `.claude/skills/`). En VS Code,
si no aparecen, activa el ajuste `chat.useAgentSkills`. Para listarlas en Copilot CLI: `/skills`.

### 2. Arranca por el orquestador
Escribe en el chat del agente:

> Usa la skill **web-orchestrator** y empieza la web.

El agente leerá `AGENTS.md`, creará `docs/estado-proyecto.md`, comprobará tu entorno (fase 0) y te
preguntará antes de instalar nada. Luego pasará a las preguntas de descubrimiento (fase 1).

### 3. Avanza fase a fase
Frases útiles:

| Quieres… | Escribe |
|---|---|
| Saber en qué punto está | "web-orchestrator: ¿en qué punto estamos?" |
| Seguir con lo siguiente | "Siguiente fase" |
| Ir a una fase concreta | "Usa web-frontend y maqueta la home" |
| Cambiar una decisión | "Cambia la dirección visual a light minimal; actualiza brief y decisiones" |
| Que decida él | "Usa la opción recomendada" (queda anotado como decisión por defecto) |
| Publicar un artículo | "Usa web-content-publishing: quiero publicar este artículo: …" |
| Regenerar la intro tras cambiar la home | "Usa web-agent-intro y regenera la captura" |
| Revisar todo antes de publicar | "Usa web-qa" |

### 4. Cosas que tendrás que hacer tú
El agente te avisará y te dará los pasos exactos, pero solo tú puedes:
- Confirmar en visionpictures.net que puedes usar los scripts de agent-cursors en una web pública
  (ya están en `tools/agent-cursors/`, ver `SOURCE.md`).
- Iniciar sesión en GitHub (`gh auth login`) con tu **cuenta personal** y elegir tu email de commits:
  la identidad git global de esta máquina es la corporativa.
- Crear cuenta en el proveedor del servidor, comprar el dominio y configurar el DNS.
- Escribir contraseñas y secretos (`.env`, secretos de GitHub). Nunca los pegues en el chat.
- Aprobar el brief, los textos y el diseño en cada puerta.

### 5. Dónde queda todo
- `docs/brief.md`: tus respuestas (requisitos).
- `docs/decisiones.md`: decisiones técnicas y su porqué.
- `docs/estado-proyecto.md`: qué fase está hecha y cómo se verificó.

## Editar o ampliar las skills
Cada skill es una carpeta con `SKILL.md` (frontmatter `name` = nombre de la carpeta + `description`, que
el agente usa para decidir cuándo cargarla) y, opcionalmente, `references/` y `templates/`. Para
añadir una, copia una existente, cambia `name`/`description` y el cuerpo. Tus datos verificados están en
`.github/skills/web-content/references/perfil-ramon-morillo.md`: si cambia tu CV, actualiza ese fichero primero.
