# Reglas para cualquier agente que trabaje en este repositorio

Este repositorio es la web personal de **Ramón Morillo** (AI Engineer): carta de presentación
para empresas + blog de artículos + proyectos personales, con una intro animada en la que
"agentes" (cursores con nombre) construyen la web en directo.

## Regla nº 1: preguntar antes de asumir

- Si falta un dato, una preferencia o una credencial, **pregunta**. No inventes y no elijas en silencio.
- Usa la herramienta de preguntas estructuradas si existe (`ask_user` en Copilot, `AskUserQuestion` en
  Claude Code). Si no existe, escribe las preguntas numeradas en el chat y **detente** hasta tener respuesta.
- Agrupa las preguntas de un mismo tema en un solo bloque (máx. ~6) y ofrece siempre una opción
  recomendada marcada como "(recomendado)" con el porqué en una línea.
- Toda respuesta del usuario se registra en `docs/brief.md` (requisitos) o `docs/decisiones.md`
  (decisiones técnicas, formato ADR corto). Antes de preguntar algo, comprueba si ya está respondido ahí.

## Regla nº 2: no inventar datos del perfil

- Los textos sobre Ramón salen **solo** de `.github/skills/web-content/references/perfil-ramon-morillo.md`
  (extraído de sus CVs) o de lo que él diga explícitamente.
- Nunca inventes cifras, clientes, premios, testimonios, titulaciones, idiomas ni fechas.
- Los ficheros `~/projects/cv_drb_*` son el CV de **otra persona (David Rivero)**: no usarlos jamás.
- Datos de proyectos de MAPFRE (nombres internos, métricas): pedir confirmación de que se pueden
  publicar antes de ponerlos en la web.

## Regla nº 3: seguir el flujo de skills

El punto de entrada es la skill **`web-orchestrator`**. Ella decide qué skill toca en cada fase y
mantiene `docs/estado-proyecto.md`. No saltes fases sin que el usuario lo pida.

| Fase | Skill |
|------|-------|
| 0. Entorno | `web-env-setup` |
| 1. Descubrimiento | `web-discovery` |
| 2. Contenido | `web-content` |
| 3. Repo GitHub | `web-github-repo` |
| 4. Estructura | `web-scaffold` |
| 5. Backend Python | `web-backend` |
| 6. Frontend Node.js | `web-frontend` |
| 7. Intro con agentes | `web-agent-intro` |
| 8. Docker | `web-docker` |
| 9. Calidad | `web-qa` |
| 10. Publicación | `web-deploy` |
| Día a día | `web-content-publishing` |

## Regla nº 4: seguridad

- Nunca imprimas variables de entorno completas (`env`, `printenv`): en esta máquina contienen
  credenciales del proxy corporativo. Filtra y enmascara (`sed 's/:[^:@]*@/:***@/'`).
- Nunca subas secretos al repo. Solo `.env.example` con valores vacíos.
- Nada de `sslverify=false` en la configuración del proyecto ni en CI.

## Regla nº 4b: código de terceros
- `tools/agent-cursors/agents.js` y `render.mjs` no se modifican nunca. `capture.mjs` solo con cambios
  generales documentados en `tools/agent-cursors/SOURCE.md`.
- `frontend/public/intro/` es generado (`make intro-capture`): nunca editarlo a mano.

## Regla nº 5: verificar

Una fase no está terminada hasta que sus comprobaciones (tests, build, `docker compose up`, check de la
intro…) pasan y el resultado queda anotado en `docs/estado-proyecto.md`.
