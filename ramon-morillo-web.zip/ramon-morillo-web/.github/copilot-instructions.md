# Instrucciones para GitHub Copilot

Lee y aplica siempre [AGENTS.md](../AGENTS.md): pregunta antes de asumir, no inventes datos del perfil,
sigue el flujo de skills de `.github/skills/` empezando por `web-orchestrator`, y nunca imprimas
variables de entorno con credenciales.
