#!/usr/bin/env node
// render.mjs · Agent cursor page -> MP4, frame by frame, so the video is always perfectly smooth.
//   node render.mjs                16:9, 3840×2160, 60 fps   -> out/agents-16x9.mp4
//   node render.mjs --vertical     9:16, 1080×1920, 60 fps   -> out/agents-9x16.mp4
//   node render.mjs --fast         half the pixels, about twice as fast
//   node render.mjs --gpu          faster with the graphics card; under load single frames can miss a layer, so the default renders without it
//   node render.mjs --check        no video: prints the numbers, saves 8 stills to out/check/ (1-4 build, 5-8 finished page).
//                                  After capture.mjs it also measures the finished build against the original (deviation).
import fs from 'node:fs';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

const require = createRequire(path.join(process.cwd(), 'x.js'));
const { chromium } = require(process.env.PLAYWRIGHT_PATH || 'playwright');
const has = k => process.argv.includes(k);
const VERT = has('--vertical'), FPS = 60, DSF = has('--fast') ? 1 : 2;
const [VW, VH] = VERT ? [1080, 1920] : [1920, 1080];
const [OW, OH] = VERT ? [1080, 1920] : [VW * DSF, VH * DSF];
const TAG = VERT ? '9x16' : '16x9', OUT = path.resolve('out'), PAGE = path.resolve('index.html');
if (!fs.existsSync(PAGE)) { console.error('index.html not found in', process.cwd()); process.exit(2); }
fs.mkdirSync(OUT, { recursive: true });

let FF = null;
for (const c of [process.env.FFMPEG_PATH, 'ffmpeg']) if (c && !spawnSync(c, ['-version']).error) { FF = c; break; }
if (!FF) { try { FF = require('ffmpeg-static'); } catch {} }

const args = ['--force-color-profile=srgb', '--disable-lcd-text', '--run-all-compositor-stages-before-draw', '--disable-checker-imaging', '--disable-new-content-rendering-timeout', ...(has('--gpu') ? ['--ignore-gpu-blocklist', '--enable-gpu-rasterization', ...(process.platform === 'darwin' ? ['--use-angle=metal'] : [])] : ['--disable-gpu'])];   // default without GPU: slower, but every frame is complete. --gpu is faster and can drop single layers for a frame
const br = await chromium.launch({ headless: true, args });
const ctx = await br.newContext({ viewport: { width: VW, height: VH }, deviceScaleFactor: DSF, reducedMotion: 'no-preference' });
const pg = await ctx.newPage();
const errors = [];
pg.on('pageerror', e => errors.push(String(e)));
pg.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
pg.on('requestfailed', r => errors.push('failed: ' + r.url()));
await pg.goto(pathToFileURL(PAGE).href + '?render=1' + (VERT ? '&reel=1' : ''));
await pg.waitForFunction(() => window.AG_READY, null, { timeout: 240000 });
const info = await pg.evaluate(() => AG.info());
const cdp = await ctx.newCDPSession(pg);
const clip = { clip: { x: 0, y: 0, width: VW, height: VH, scale: DSF } };
const shot = async () => Buffer.from((await cdp.send('Page.captureScreenshot', { format: 'jpeg', quality: 93, optimizeForSpeed: true, ...clip })).data, 'base64');
const report = o => console.log(JSON.stringify({ seconds: +info.dauer.toFixed(1), agents: info.agenten, layers: info.ebenen, tasks: info.aufgaben, pageHeight: info.seitenH, errors: errors.length, errorList: errors.slice(0, 6), ffmpeg: FF ? 'yes' : 'no', ...o }));

// Finished build against the screenshots of the original, at the same scroll positions: mean color difference and share of visibly changed pixels
async function compare(S, dir) {
  await pg.evaluate(d => { AG.tick(d); for (const s of ['.ag-chrome', '.ag-pille']) { const e = document.querySelector(s); if (e) e.style.display = 'none'; } const v = document.querySelector('.ag-sicht'); v.style.top = '0'; v.style.height = '100%'; }, info.dauer);
  const helper = await ctx.newPage(), rows = [];
  for (const [i, s] of S.shots.entries()) {
    const y = s.y;
    await pg.evaluate(y => { document.querySelector('.ag-rolle').style.transform = `translate3d(0,${-y}px,0)`; }, y);
    await pg.waitForTimeout(80);
    const nn = String(i).padStart(2, '0'), mine = Buffer.from((await cdp.send('Page.captureScreenshot', { format: 'jpeg', quality: 92, clip: { x: 0, y: 0, width: VW, height: VH, scale: 1 } })).data, 'base64');
    const orig = fs.readFileSync(path.join(OUT, 'original', s.file));
    const r = await helper.evaluate(async ([a, b]) => {
      const load = d => new Promise((ok, no) => { const m = new Image(); m.onload = () => ok(m); m.onerror = no; m.src = 'data:image/jpeg;base64,' + d; });
      const [A, B] = await Promise.all([load(a), load(b)]), w = 960, h = 540, cv = document.createElement('canvas'); cv.width = w * 2 + 12; cv.height = h;
      const g = cv.getContext('2d', { willReadFrequently: true }); g.fillStyle = '#ff2d55'; g.fillRect(0, 0, cv.width, h); g.drawImage(A, 0, 0, w, h); g.drawImage(B, w + 12, 0, w, h);
      const p = g.getImageData(0, 0, w, h).data, q = g.getImageData(w + 12, 0, w, h).data; let sum = 0, ch = 0;
      for (let i = 0; i < p.length; i += 4) { const d = [Math.abs(p[i] - q[i]), Math.abs(p[i + 1] - q[i + 1]), Math.abs(p[i + 2] - q[i + 2])]; sum += d[0] + d[1] + d[2]; if (Math.max(...d) > 40) ch++; }
      return { mean: +(sum / (w * h * 3 * 255) * 100).toFixed(2), changed: +(ch / (w * h) * 100).toFixed(2), side: cv.toDataURL('image/jpeg', 0.86).split(',')[1] };
    }, [orig.toString('base64'), mine.toString('base64')]);
    fs.writeFileSync(path.join(dir, `compare-${nn}.jpg`), Buffer.from(r.side, 'base64'));
    rows.push({ y, mean: r.mean, changed: r.changed });
  }
  await helper.close();
  const avg = k => +(rows.reduce((s, r) => s + r[k], 0) / rows.length).toFixed(2), worst = rows.reduce((a, b) => (b.changed > a.changed ? b : a));
  return { meanColorDiffPct: avg('mean'), changedPixelsPct: avg('changed'), worst, positions: rows.length, spots: rows.map((r, i) => `${String(i).padStart(2, '0')}:y${r.y}=${r.changed}%`).join(' '), pass: avg('changed') <= 5 && worst.changed <= 30, sideBySide: path.join(dir, 'compare-*.jpg (left original, right build)') };
}

if (has('--check')) {
  const dir = path.join(OUT, 'check'); fs.mkdirSync(dir, { recursive: true });
  const [s0, s1] = info.scroll, times = [0.12, 0.3, 0.5, 0.75].map(p => info.bauEnde * p).concat([0, 0.22, 0.34, 1].map(p => s0 + (s1 - s0) * p));   // 1-4 build, 5-8 finished page from bottom to top
  for (const [i, t] of times.entries()) { await pg.evaluate(t => AG.tick(t), t); fs.writeFileSync(path.join(dir, `${TAG}-${String(i + 1).padStart(2, '0')}.jpg`), await shot()); }
  const ref = path.join(OUT, 'original', 'shots.json');
  const deviation = !VERT && fs.existsSync(ref) ? await compare(JSON.parse(fs.readFileSync(ref, 'utf8')), dir) : undefined;
  report({ stills: dir, deviation }); await br.close(); process.exit(errors.length || (deviation && !deviation.pass) ? 1 : 0);
}

const until = has('--until') ? +process.argv[process.argv.indexOf('--until') + 1] : info.dauer;
const N = Math.round(Math.min(until, info.dauer) * FPS), mp4 = path.join(OUT, `agents-${TAG}.mp4`), t0 = Date.now();
const framesDir = path.join(OUT, `frames-${TAG}`);
let ff = null;
if (FF) ff = spawn(FF, ['-loglevel', 'error', '-y', '-f', 'image2pipe', '-framerate', String(FPS), '-c:v', 'mjpeg', '-i', '-', '-vf', `scale=${OW}:${OH}:flags=lanczos,format=yuv420p`,
  '-c:v', 'libx264', '-crf', VERT ? '15' : '17', '-preset', 'medium', '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-r', String(FPS), '-movflags', '+faststart', mp4], { stdio: ['pipe', 'inherit', 'inherit'] });
else fs.mkdirSync(framesDir, { recursive: true });
for (let i = 0; i < N; i++) {
  await pg.evaluate(t => new Promise(ok => { AG.tick(t); requestAnimationFrame(() => requestAnimationFrame(ok)); }), i / FPS);   // wait until the frame is really on screen
  let b = await shot();
  for (let k = 0; k < 6; k++) { const c = await shot(); if (c.equals(b)) break; b = c; }   // a frame counts once two captures match: under load the browser sometimes draws a frame with layers missing
  if (ff) { if (!ff.stdin.write(b)) await new Promise(r => ff.stdin.once('drain', r)); }
  else fs.writeFileSync(path.join(framesDir, `${String(i).padStart(6, '0')}.jpg`), b);
  if (i % 120 === 0) console.log(`frame ${i}/${N}  ${((Date.now() - t0) / 1000).toFixed(0)} s`);
}
await br.close();
if (!ff) {
  report({ frames: N, framesDir, fix: `ffmpeg missing. Install it, then run: ffmpeg -framerate ${FPS} -i "${framesDir}/%06d.jpg" -vf scale=${OW}:${OH},format=yuv420p -c:v libx264 -crf 17 "${mp4}"` });
  process.exit(3);
}
ff.stdin.end(); const code = await new Promise(r => ff.on('close', r));
const size = fs.existsSync(mp4) ? fs.statSync(mp4).size : 0;
let sheet = null;
if (size) { sheet = path.join(OUT, `sheet-${TAG}.jpg`); spawnSync(FF, ['-v', 'error', '-y', '-i', mp4, '-vf', `fps=1,scale=${VERT ? 270 : 640}:-1,tile=6x${Math.ceil(info.dauer / 6)}`, '-frames:v', '1', '-q:v', '3', sheet]); }
report({ video: mp4, sizeMB: +(size / 1e6).toFixed(1), frames: N, resolution: `${OW}x${OH}`, fps: FPS, renderSeconds: Math.round((Date.now() - t0) / 1000), contactSheet: sheet });
process.exit(code || !size ? 1 : 0);
