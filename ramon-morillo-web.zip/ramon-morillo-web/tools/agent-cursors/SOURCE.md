# agent-cursors · origen y control de cambios

| Fichero | Origen | Recibido | sha256 | Modificado |
|---|---|---|---|---|
| `agents.js` | https://visionpictures.net/free/agent-cursors/agents.js | 2026-11-23 (pegado por Ramón; el proxy corporativo bloquea la descarga) | `5e038b87960f55d19e899568b16c311120ef5616426b8b16b22075e358085359` | **No. No modificar.** |
| `render.mjs` | https://visionpictures.net/free/agent-cursors/render.mjs | 2026-11-23 (ídem) | `fc62f732f7e607ac747a950dd6c9ae0615bcdba61ce5af8655c25791d1a7da0d` | **No. No modificar.** |
| `capture.mjs` | https://visionpictures.net/free/agent-cursors/capture.mjs | 2026-11-23 (ídem) | original `1f27cb14be77170c50d876c2ec0b989fc0f6e4bc30041decf2ce886d8b492875` · actual `066c157df935671e708b348a44745f1b925df971b30905ef2966aeb6f21d79f9` | Sí, ver abajo |

Verificar: `sha256sum agents.js render.mjs capture.mjs`.

## Licencia / términos
Cabecera de `agents.js`: *"Agent cursor build. Free from visionpictures.net. Geist fonts: SIL OFL 1.1."*
No hay más texto de licencia en los ficheros. **Pendiente**: que Ramón confirme en visionpictures.net que el uso
en una web pública está permitido (el agente no puede aceptar términos).

## Revisión de seguridad (2026-11-23)
- `agents.js`: sin `fetch`, `XMLHttpRequest`, `WebSocket`, `sendBeacon`, `eval`, `new Function` ni `import()`;
  sin URLs externas. Solo CSS y fuentes Geist embebidas en base64. Se ejecuta en el navegador del visitante.
- `render.mjs` y `capture.mjs`: se ejecutan solo en local/CI con Playwright headless. `capture.mjs` solo
  descarga los recursos de la página que se le indica.

## Modificación local de `capture.mjs`
Flag opcional `--label=<dominio>` → añade `data-url="<dominio>"` al `<script src="agents.js">` para que la barra
de navegador simulada muestre el dominio real en vez de `localhost:3000`. Sin el flag, el comportamiento es el
original. Si llega una versión nueva de `capture.mjs`, reaplicar:
```diff
 const input = process.argv.slice(2).find(a => !a.startsWith('--'));
+const LABEL = (process.argv.find(a => a.startsWith('--label=')) || '').slice('--label='.length);
 ...
 const accent = F.accent ? ` data-accent="${F.accent}"` : '';
+const label = LABEL ? ` data-url="${esc(LABEL)}"` : '';
 ...
-<script src="agents.js"${accent} data-title="...">
+<script src="agents.js"${accent}${label} data-title="...">
```
Las correcciones de fidelidad de captura (cuando `render.mjs --check` muestre diferencias) se hacen también
aquí, como reglas generales, y se documentan en esta sección.
