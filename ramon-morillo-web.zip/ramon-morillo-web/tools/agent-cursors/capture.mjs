#!/usr/bin/env node
// capture.mjs · Freezes a real page 1:1 into ./index.html + ./assets, ready for the agent cursors.
//   node capture.mjs https://your-site.com        a live page
//   node capture.mjs ./project/index.html         a local file or folder
//   node capture.mjs http://localhost:3000        a running dev server
// Result: every element keeps its real text, images, fonts, colors and layout, resolved to plain px at 1920 wide,
// without scripts, media queries or animation. Reference screenshots of the original go to out/original/ so that
// `node render.mjs --check` can measure how exactly the finished build matches it.
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { pathToFileURL, fileURLToPath } from 'node:url';

const require = createRequire(path.join(process.cwd(), 'x.js'));
const { chromium } = require(process.env.PLAYWRIGHT_PATH || 'playwright');
const W = 1920, VH = 1080, MAX_H = 60000;
const input = process.argv.slice(2).find(a => !a.startsWith('--'));
// Local addition (ramon-morillo-web): --label=example.com sets data-url, the address shown in the simulated browser bar.
const LABEL = (process.argv.find(a => a.startsWith('--label=')) || '').slice('--label='.length);
if (!input) { console.error('usage: node capture.mjs <url or path>'); process.exit(2); }
let url = input;
if (!/^https?:|^file:/.test(input)) {
  let p = path.resolve(input);
  if (fs.existsSync(p) && fs.statSync(p).isDirectory()) p = path.join(p, 'index.html');
  if (fs.existsSync(p)) url = pathToFileURL(p).href; else url = 'https://' + input;
}
const OUT = path.resolve('out/original'), ASSETS = path.resolve('assets');
fs.mkdirSync(OUT, { recursive: true }); fs.mkdirSync(ASSETS, { recursive: true });
const wait = ms => new Promise(r => setTimeout(r, ms));

const args = ['--force-color-profile=srgb', '--disable-lcd-text', '--ignore-gpu-blocklist', '--enable-gpu-rasterization', '--enable-unsafe-swiftshader', ...(process.platform === 'darwin' ? ['--use-angle=metal'] : [])];
const br = await chromium.launch({ headless: true, args });
const ctx = await br.newContext({ viewport: { width: W, height: VH }, deviceScaleFactor: 1, bypassCSP: true, reducedMotion: 'no-preference',
  userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36' });
const page = await ctx.newPage();
const responses = new Map(), sheets = [];
page.on('response', r => {
  const t = r.request().resourceType(), u = r.url();
  if (t === 'stylesheet') sheets.push(r);
  if (t === 'font' || t === 'image' || t === 'media') responses.set(u, r);
});

// ---------- runs inside the page ----------
function install() {
  const C = window.__cap = { seen: new Map() };
  // content-visibility:auto skips layout off screen, and skipped boxes report wrong values (auto margins as 0px). Everything must be laid out to be measured.
  const laid = document.createElement('style'); laid.textContent = '*{content-visibility:visible!important}'; document.head.appendChild(laid);
  const label = e => [e.id, e.getAttribute('class'), e.getAttribute('aria-label'), e.getAttribute('data-testid'), e.localName].join(' ');
  const WORD = /cookie|consent|gdpr|onetrust|usercentrics|didomi|cookiebot|klaro|borlabs|truste|qc-cmp|sp_message|cc-window|cmp-?(wrapper|root|banner|container)|newsletter-?(popup|modal)|exit-?intent|chat-?widget|intercom|crisp|tawk|livechat|hubspot-messages|hs-web-interactives|tidio|zendesk|drift-/i;
  const BANNER_TEXT = /cookie|consent|datenschutz|privacy|tracking/i;
  const scroller = C.scroller = () => {
    const root = document.scrollingElement || document.documentElement;
    if (root.scrollHeight > innerHeight + 50) return root;
    let best = null, top = 0;
    for (const e of document.querySelectorAll('body, body *')) {
      if (e.scrollHeight <= e.clientHeight + 200) continue;
      if (!/auto|scroll|hidden/.test(getComputedStyle(e).overflowY)) continue;
      const r = e.getBoundingClientRect();
      if (r.width >= innerWidth * 0.6 && r.height >= innerHeight * 0.5 && e.scrollHeight > top) { top = e.scrollHeight; best = e; }
    }
    return best || root;
  };
  C.height = () => Math.max(scroller().scrollHeight, document.documentElement.scrollHeight);
  C.scrollTo = y => scroller().scrollTo({ top: y, left: 0, behavior: 'instant' });
  C.scrollY = () => scroller().scrollTop;
  // Overlays are left out of the frozen copy; the page behind them stays untouched.
  C.clearOverlays = () => {
    let n = 0;
    const leave = e => { e.setAttribute('data-cap-out', ''); e.style.setProperty('display', 'none', 'important'); n++; };
    for (const e of document.querySelectorAll('body *')) {
      if (e.hasAttribute('data-cap-out')) continue;
      const c = getComputedStyle(e);
      if (c.display === 'none') continue;
      const fixed = c.position === 'fixed', r = e.getBoundingClientRect(), area = (r.width * r.height) / (innerWidth * innerHeight);
      if (e.shadowRoot && WORD.test(label(e))) { leave(e); continue; }
      if (!fixed && !(e.localName === 'dialog' && e.open) && e.getAttribute('aria-modal') !== 'true') continue;
      const dialog = /dialog/.test(e.getAttribute('role') || '') || e.getAttribute('aria-modal') === 'true' || e.localName === 'dialog';
      if (WORD.test(label(e)) || (dialog && area > 0.02)) { leave(e); continue; }
      if (area > 0.01 && area < 0.7 && BANNER_TEXT.test(e.innerText || '') && e.querySelector('button,a,[role=button]')) { leave(e); continue; }
      const a = (c.backgroundColor.match(/[\d.]+/g) || [0, 0, 0, 0])[3];
      if (area > 0.9 && a != null && +a > 0.05 && +a < 0.95 && !(e.innerText || '').trim()) leave(e);
    }
    if (n) for (const e of [document.documentElement, document.body]) if (getComputedStyle(e).overflowY === 'hidden') { e.style.setProperty('overflow', 'visible', 'important'); e.style.setProperty('overflow-y', 'auto', 'important'); }
    return n;
  };
  // Every element keeps the state it last had in the middle of the screen. One moment for all, so scroll reveals stay revealed and carousels show one slide.
  C.remember = () => {
    const vh = innerHeight;
    for (const e of document.querySelectorAll('body *')) {
      let r = e.getBoundingClientRect();
      if (r.width < 1 || r.height < 1) {
        // A reveal that ends collapsed (scaleX(0), scale 0) has no painted box, but its state still counts: measure the box it has without the transform.
        const q = getComputedStyle(e);
        if (q.transform === 'none' && q.scale === 'none') continue;
        const t = e.style.getPropertyValue('transform'), tp = e.style.getPropertyPriority('transform'), sc = e.style.getPropertyValue('scale'), sp = e.style.getPropertyPriority('scale');
        e.style.setProperty('transform', 'none', 'important'); e.style.setProperty('scale', 'none', 'important');
        r = e.getBoundingClientRect();
        if (t) e.style.setProperty('transform', t, tp); else e.style.removeProperty('transform');
        if (sc) e.style.setProperty('scale', sc, sp); else e.style.removeProperty('scale');
        if (r.width < 1 || r.height < 1) continue;
      }
      const mid = (r.top + r.bottom) / 2;
      if (!(r.height < vh ? mid > vh * 0.08 && mid < vh * 0.92 : r.top < vh * 0.85 && r.bottom > vh * 0.15)) continue;
      if (e.closest('[data-cap-pin]')) continue;
      const c = getComputedStyle(e);
      C.seen.set(e, { opacity: c.opacity, transform: c.transform, visibility: c.visibility, 'clip-path': c.clipPath, filter: c.filter, 'fill-opacity': c.fillOpacity, 'stroke-opacity': c.strokeOpacity, stroke: c.stroke, 'stroke-dashoffset': c.strokeDashoffset });
    }
  };
  // A fingerprint of everything in the middle of the screen. Scroll reveals ease in over a second or more, so a state counts only once this stops changing.
  C.sig = () => {
    const vh = innerHeight; let h = 0;
    for (const e of document.querySelectorAll('body *')) {
      const r = e.getBoundingClientRect();
      if (r.bottom < vh * 0.05 || r.top > vh * 0.95) continue;
      const c = getComputedStyle(e), k = c.opacity + c.transform + c.clipPath + Math.round(r.top) + Math.round(r.width);
      for (let i = 0; i < k.length; i++) h = (h * 31 + k.charCodeAt(i)) | 0;
    }
    return h;
  };
  C.settle = () => { for (const a of document.getAnimations()) { try { const it = a.effect && a.effect.getComputedTiming(); if (it && it.iterations === Infinity) a.pause(); else a.finish(); } catch {} } };
  C.pinned = on => {
    for (const e of document.querySelectorAll('body *')) {
      if (e.hasAttribute('data-cap-out')) continue;
      if (!e.hasAttribute('data-cap-pin')) { const p = getComputedStyle(e).position; if (p === 'fixed' || p === 'sticky') { const r = e.getBoundingClientRect(); if (r.height < innerHeight * 0.9) e.setAttribute('data-cap-pin', ''); } }
      if (e.hasAttribute('data-cap-pin')) on ? e.style.removeProperty('visibility') : e.style.setProperty('visibility', 'hidden', 'important');
    }
  };
  // A pin is a viewport-high panel that sticks while a long empty track scrolls past it. Frozen, it is one panel in its revealed state.
  C.findPins = () => {
    const sc = scroller(), y0 = sc.scrollTop, pins = C.pins = [];
    for (const e of document.querySelectorAll('body *')) {
      if (pins.some(p => p.track.contains(e))) continue;
      const c = getComputedStyle(e);
      if (c.display === 'none') continue;
      let el, track;
      if (e.classList.contains('pin-spacer') && e.firstElementChild) { track = e; el = e.firstElementChild; }
      else if (c.position === 'sticky') { el = e; track = e.parentElement; }
      else continue;
      const r = el.getBoundingClientRect();
      if (r.height < innerHeight * 0.6) continue;
      while (track && track !== document.body && track.getBoundingClientRect().height <= r.height * 1.25) track = track.parentElement;
      if (!track || track === document.body) continue;
      const t = track.getBoundingClientRect();
      const others = [...track.children].filter(k => k !== el && !k.contains(el) && getComputedStyle(k).display !== 'none' && !/absolute|fixed/.test(getComputedStyle(k).position) && k.getBoundingClientRect().height > 40);
      if (others.length) continue;
      const travel = t.height - r.height;
      pins.push({ el, track, top: t.top + y0, h: r.height, travel, panels: Math.max(1, Math.min(4, Math.round(travel / (r.height * 1.2)))) });
    }
    return pins.map(({ top, h, travel, panels }) => ({ top, h, travel, panels }));
  };
  // How much readable text a pin shows at this moment: used to pick its best state
  C.pinScore = i => {
    const p = C.pins[i].el, w = document.createTreeWalker(p, NodeFilter.SHOW_TEXT);
    let n = 0;
    while (w.nextNode()) {
      const t = w.currentNode, s = t.data.trim(), e = t.parentElement;
      if (!s || !e) continue;
      const r = e.getBoundingClientRect();
      if (r.width < 1 || r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) continue;
      let o = 1;
      for (let a = e; a && a !== p.parentElement; a = a.parentElement) { const c = getComputedStyle(a); o *= +c.opacity; if (c.visibility === 'hidden' || c.display === 'none') { o = 0; break; } }
      if (o > 0.5) n += s.length;
    }
    return n;
  };
  C.isolate = e => {
    let st = document.getElementById('cap-iso');
    document.querySelectorAll('[data-cap-iso]').forEach(x => x.removeAttribute('data-cap-iso'));
    if (!e) { if (st) st.remove(); return; }
    e.setAttribute('data-cap-iso', '');
    if (!st) { st = document.createElement('style'); st.id = 'cap-iso'; st.textContent = 'html,body{background:transparent!important}body *{visibility:hidden!important}[data-cap-iso]{visibility:visible!important}'; document.head.appendChild(st); }
  };
  C.accent = () => {
    const n = new Map(), add = (c, w) => { const m = (c.match(/[\d.]+/g) || []).map(Number); if (m.length < 3 || (m[3] != null && m[3] < 0.5)) return; if (Math.max(m[0], m[1], m[2]) - Math.min(m[0], m[1], m[2]) < 70) return; const h = '#' + m.slice(0, 3).map(v => Math.round(v).toString(16).padStart(2, '0')).join(''); n.set(h, (n.get(h) || 0) + w); };
    for (const e of document.querySelectorAll('a,button,[role=button]')) add(getComputedStyle(e).backgroundColor, 3);
    for (const e of document.querySelectorAll('h1,h2,h3,h1 *,h2 *,a')) add(getComputedStyle(e).color, 1);
    return [...n].sort((a, b) => b[1] - a[1]).map(x => x[0])[0] || '';
  };

  C.prepare = () => {
    if (C.ser) return;
    const root = document.documentElement, body = document.body, sc = scroller(), pins = C.pins || [], urls = [], pinned = [];
    for (const p of pins) p.fold = p.travel - (p.panels - 1) * p.h;
    const fold = pins.reduce((s, p) => s + p.fold, 0), H = Math.min(C.height(), 60000) - fold;
    const shrink = new Map(), pinHtml = new Map(), tracks = new Map(pins.map(p => [p.track, p])), inPin = e => pins.some(p => p.el.contains(e));
    for (const p of pins) for (let a = p.track.parentElement; a && a !== root; a = a.parentElement) shrink.set(a, (shrink.get(a) || 0) + p.fold);
    const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    const tok = u => { if (!u || u.startsWith('data:')) return u; let i = urls.indexOf(u); if (i < 0) { urls.push(u); i = urls.length - 1; } return `__CAPASSET${i}__`; };
    const frame = document.createElement('iframe');
    frame.style.cssText = 'position:absolute;left:-9999px;top:0;width:1920px;height:1080px;border:0';
    root.appendChild(frame);
    const fd = frame.contentDocument; fd.open(); fd.write('<!doctype html><html><head></head><body></body></html>'); fd.close();
    const defaults = new Map();
    const standard = (tag, svg, type) => {
      const k = (svg ? 'svg:' : '') + tag + (type ? ':' + type : '');
      if (defaults.has(k)) return defaults.get(k);
      const x = svg ? fd.createElementNS('http://www.w3.org/2000/svg', tag) : fd.createElement(/^[a-z][a-z0-9-]*$/i.test(tag) ? tag : 'div');
      if (tag === 'a') x.setAttribute('href', '#');
      if (type) x.setAttribute('type', type);   // a checkbox has other browser defaults (margin 3px 3px 3px 4px) than a text field
      fd.body.appendChild(x);
      const c = frame.contentWindow.getComputedStyle(x), o = {};
      for (let i = 0; i < c.length; i++) o[c[i]] = c.getPropertyValue(c[i]);
      x.remove(); defaults.set(k, o); return o;
    };
    const INHERITED = new Set('color font-family font-size font-style font-variant-caps font-variant-ligatures font-variant-numeric font-variant-east-asian font-variant-alternates font-variant-position font-weight font-stretch font-feature-settings font-kerning font-optical-sizing font-variation-settings font-synthesis-weight font-synthesis-style font-synthesis-small-caps letter-spacing line-height text-align text-align-last text-indent text-transform text-shadow text-rendering text-wrap-mode text-wrap-style white-space-collapse word-break word-spacing overflow-wrap visibility direction list-style-type list-style-position list-style-image quotes tab-size hyphens -webkit-font-smoothing -webkit-text-fill-color -webkit-text-stroke-width text-size-adjust fill fill-opacity fill-rule stroke stroke-width stroke-opacity stroke-linecap stroke-linejoin stroke-dasharray stroke-dashoffset paint-order'.split(' '));
    const DROP = /^(--|animation|transition|will-change|cursor|pointer-events|user-select|-webkit-user|-webkit-tap|-webkit-rtl|scroll-|overscroll|view-t|anchor|position-|interpolate|caret|accent-color|color-scheme|forced-color|print-color|-webkit-print|orphans|widows|page|speak|ruby|text-emphasis|column-rule|container|contain-intrinsic|content-visibility|field-sizing|timeline|offset|shape-|tab-size|touch-action|d$|cx$|cy$|rx$|ry$|r$|x$|y$|flood|lighting|marker|vector-effect|buffered|color-interpolation|color-rendering|shape-rendering|dominant|alignment-baseline|baseline-shift$|mask-type|writing-mode$)|^(block-size|inline-size|min-block-size|max-block-size|min-inline-size|max-inline-size)$|^(margin|padding|border|inset|scroll-margin|scroll-padding)-(block|inline)/;
    const SVG_DROP = /^(width|height|transform-origin|perspective-origin|display)$/;
    const skip = (p, c, def) => {
      if (DROP.test(p)) return true;
      const b = p.match(/^border-(top|right|bottom|left)-(color|style|width)$/);
      if (b) return c.getPropertyValue(`border-${b[1]}-style`) === 'none' && (b[2] !== 'style' || def[p] === 'none');
      if (p.startsWith('outline-')) return c.outlineStyle === 'none' && (p !== 'outline-style' || def[p] === 'none');
      if (p === 'text-decoration-color' || p === 'text-decoration-style' || p === 'text-decoration-thickness') return !/underline|overline|line-through/.test(c.textDecorationLine);
      if (p === 'transform-origin') return c.transform === 'none' && c.rotate === 'none' && c.scale === 'none' && c.translate === 'none';
      if (p === 'perspective-origin') return c.perspective === 'none';
      if (p === '-webkit-text-fill-color') return c.getPropertyValue(p) === c.color;
      return false;
    };
    const styleOf = (c, tag, parent, svg, svgInner, over, el) => {
      const def = standard(tag, svg, tag === 'input' && el ? el.type : ''), base = standard('div', false), out = [];
      // Form controls do not inherit colour, font, spacing: the browser sets its own (button: color buttontext). Written as "inherited" a white button label would fall back to black in the build.
      const FORM = tag === 'button' || tag === 'input' || tag === 'select' || tag === 'textarea' || tag === 'optgroup' || tag === 'option';
      // Sprite icons (<symbol>) draw in the colour of the <use> that shows them. Inside the hidden sprite currentColor resolves against the sprite's host, so it must be written back as currentColor.
      const inDefs = !!(svgInner && el && el.closest && el.closest('symbol,defs,pattern,marker,mask,clipPath'));
      // Gradient text from a shorthand with two layers computes to "background-clip: text, text" and "linear-gradient(..), none". The build only knows the plain single "text" clip and would show the box instead of the text (invisible, fill is transparent). So: one clip value, and layers without an image are dropped.
      const splitTop = t => { const r = []; let d = 0, a = 0; for (let i = 0; i < t.length; i++) { const ch = t[i]; if (ch === '(') d++; else if (ch === ')') d--; else if (ch === ',' && d === 0) { r.push(t.slice(a, i).trim()); a = i + 1; } } r.push(t.slice(a).trim()); return r; };
      const textClip = splitTop(c.getPropertyValue('background-clip')).every(k => k === 'text');
      const layerN = splitTop(c.getPropertyValue('background-image')).length;
      const keepLayers = textClip ? splitTop(c.getPropertyValue('background-image')).map((m, i) => (m !== 'none' ? i : -1)).filter(i => i >= 0) : [];
      if (textClip && !keepLayers.length) keepLayers.push(0);
      for (let i = 0; i < c.length; i++) {
        const p = c[i];
        if (skip(p, c, def) || (svgInner && SVG_DROP.test(p))) continue;
        if (over && p in over) continue;
        let v = c.getPropertyValue(p);
        // A value only stays inherited if the browser has no own rule for this tag (a, h1, button ...)
        const same = INHERITED.has(p) && parent && !FORM && def[p] === base[p] ? v === parent.getPropertyValue(p) : v === def[p];
        // Chrome reports display:-webkit-box + -webkit-line-clamp as flow-root. Only the -webkit-box form shows the clamp and its ellipsis, so it is written back.
        if (p === 'display' && v === 'flow-root' && el && c.getPropertyValue('-webkit-line-clamp') !== 'none' && c.getPropertyValue('-webkit-box-orient') === 'vertical') {
          const n = parseInt(c.getPropertyValue('-webkit-line-clamp'), 10), lh = parseFloat(c.lineHeight);
          const inner = parseFloat(c.height) - (c.boxSizing === 'border-box' ? ['paddingTop', 'paddingBottom', 'borderTopWidth', 'borderBottomWidth'].reduce((a, k) => a + (parseFloat(c[k]) || 0), 0) : 0);
          if (n > 0 && (isNaN(lh) || inner <= n * lh + 1.5)) v = '-webkit-box';
        }
        // With a border style set, a width of 0 must be written too: left out, the browser would fall back to 3px (common: * { border: 0 solid })
        const keepWidth = /^(border-(top|right|bottom|left)|outline)-width$/.test(p) && c.getPropertyValue(p.replace('width', 'style')) !== 'none';
        if ((same && !keepWidth) || v === '') continue;
        if (inDefs && (p === 'fill' || p === 'stroke') && v === c.color) { const at = el.getAttribute(p); if (at === null || /^currentcolor$/i.test(at.trim())) v = 'currentColor'; }
        if (p === 'background-attachment') v = v.replace(/fixed/g, 'scroll');
        if (textClip && p === 'background-clip') v = 'text';
        else if (textClip && keepLayers.length < layerN && /^background-(attachment|blend-mode|image|origin|position|position-x|position-y|repeat|size)$/.test(p)) { const parts = splitTop(v); if (parts.length === layerN) v = keepLayers.map(i => parts[i]).join(', '); }
        if (v.includes('url(')) v = v.replace(/url\("([^"]+)"\)/g, (m, u) => (u.startsWith('#') ? m : `url("${tok(u)}")`));
        out.push(p + ':' + v);
      }
      if (over) for (const k in over) out.push(k + ':' + over[k]);
      return out.join(';');
    };
    const VOID = new Set('img input br hr wbr area col'.split(' '));
    const SKIP_TAG = new Set('script style link meta noscript template title head base source track'.split(' '));
    const HTML_ATTR = ['alt', 'colspan', 'rowspan', 'type', 'placeholder', 'lang', 'dir', 'width', 'height', 'disabled', 'start', 'reversed'];
    const pseudo = (e, which, ec) => {
      const c = getComputedStyle(e, which), content = c.content;
      if (!content || content === 'none' || content === 'normal' || c.display === 'none') return '';
      // A <q> prints its own quotation marks in the build, in the page's locale. Writing them out as well would print every mark twice.
      if (e.localName === 'q' && /^(open|close)-quote$/.test(content)) return '';
      let text = '', img = null;
      const marks = () => {
        const qs = getComputedStyle(e).quotes, l = [...qs.matchAll(/"((?:[^"\\]|\\.)*)"/g)].map(x => x[1]);
        if (l.length >= 2) return [l[0], l[1]];
        if (qs === 'none') return ['', ''];
        const lang = ((e.closest('[lang]') || {}).lang || document.documentElement.lang || 'en').slice(0, 2).toLowerCase();
        return { de: ['\u201E', '\u201C'], fr: ['\u00AB\u00A0', '\u00A0\u00BB'], es: ['\u00AB', '\u00BB'], it: ['\u00AB', '\u00BB'] }[lang] || ['\u201C', '\u201D'];
      };
      for (const m of content.matchAll(/"((?:[^"\\]|\\.)*)"|url\("([^"]+)"\)|open-quote|close-quote/g)) { if (m[0] === 'open-quote') text += marks()[0]; else if (m[0] === 'close-quote') text += marks()[1]; else if (m[2]) img = m[2]; else text += m[1].replace(/\\(.)/g, '$1'); }
      const st = styleOf(c, img ? 'img' : 'span', ec, false, false, null);
      return img ? `<img src="${esc(tok(img))}" alt="" style="${esc(st)}">` : `<span style="${esc(st)}">${esc(text)}</span>`;
    };
    const kids = e => {
      const r = e.shadowRoot || e, out = [];
      for (const n of r.childNodes) {
        if (n.nodeType === 1 && n.localName === 'slot') { const a = n.assignedNodes({ flatten: true }); out.push(...(a.length ? a : n.childNodes)); }
        else out.push(n);
      }
      return out;
    };
    const overFor = (e, c) => {
      const o = {}, s = inPin(e) ? null : C.seen.get(e);
      if (s) for (const k in s) if (s[k] !== c.getPropertyValue(k)) o[k] = s[k];
      if (shrink.has(e) && c.display !== 'inline') { o.height = Math.max(0, parseFloat(c.height) - shrink.get(e)) + 'px'; o['min-height'] = '0px'; }
      if (tracks.has(e)) { const p = tracks.get(e); o.height = p.h * p.panels + 'px'; o['min-height'] = '0px'; o['padding-top'] = o['padding-bottom'] = '0px'; }
      if (c.position === 'sticky') { o.position = 'relative'; o.top = o.left = o.right = o.bottom = 'auto'; }
      // Chrome can report an auto margin as 0px although it moves the box. Whether it does is measured: set the margin to 0 for a moment and see if the box jumps. Works in every layout.
      if (e !== body && e.parentElement && e.parentElement !== root && !c.display.startsWith('inline') && c.float === 'none' && /static|relative/.test(c.position)) {
        const pr = e.parentElement.getBoundingClientRect(), r0 = e.getBoundingClientRect(), pd = getComputedStyle(e.parentElement).display;
        const jump = (side, edge) => {
          const old = e.style.getPropertyValue(side), pri = e.style.getPropertyPriority(side);
          e.style.setProperty(side, '0px', 'important');
          const d = r0[edge] - e.getBoundingClientRect()[edge];
          if (old) e.style.setProperty(side, old, pri); else e.style.removeProperty(side);
          return d;
        };
        if (c.marginLeft === '0px' && r0.width < pr.width - 2) { const d = jump('margin-left', 'left'); if (Math.abs(d) > 1) o['margin-left'] = +d.toFixed(2) + 'px'; }
        if (c.marginTop === '0px' && r0.height < pr.height - 2 && /flex|grid/.test(pd)) { const d = jump('margin-top', 'top'); if (Math.abs(d) > 1) o['margin-top'] = +d.toFixed(2) + 'px'; }
      }
      // A last child's bottom margin collapses through a parent with height:auto and no padding or border below, so the gap sits outside the parent. The build pins every height, which stops that: the parent takes the margin itself.
      if (e !== body && e.parentElement && !inPin(e) && /^(block|list-item)$/.test(c.display) && /^(static|relative)$/.test(c.position) && c.float === 'none' && c.overflowY === 'visible' && c.overflowX === 'visible' && c.contain === 'none' && !(parseFloat(c.paddingBottom) || 0) && !(parseFloat(c.borderBottomWidth) || 0) && !/flex|grid/.test(getComputedStyle(e.parentElement).display)) {
        const er = e.getBoundingClientRect();
        let eff = 0;
        for (let k = e.lastElementChild; k; k = k.lastElementChild) {
          const kc = getComputedStyle(k);
          if (kc.display === 'none' || /absolute|fixed/.test(kc.position) || kc.float !== 'none' || !/^(block|list-item|flex|grid|table)$/.test(kc.display)) break;
          if (Math.abs(k.getBoundingClientRect().bottom - er.bottom) > 1) break;
          eff = Math.max(eff, parseFloat(kc.marginBottom) || 0);
          if (!/^(block|list-item)$/.test(kc.display) || kc.overflowY !== 'visible' || kc.contain !== 'none' || (parseFloat(kc.paddingBottom) || 0) || (parseFloat(kc.borderBottomWidth) || 0)) break;
        }
        const own = parseFloat(c.marginBottom) || 0;
        if (own >= 0 && eff > own + 0.5) o['margin-bottom'] = +eff.toFixed(2) + 'px';
      }
      // During the build every painted box gets its own stacking context. A static box whose children carry a z-index would trap them, so the box takes that z-index itself.
      const paints = c.backgroundImage !== 'none' || !/rgba\(0, 0, 0, 0\)|transparent/.test(c.backgroundColor) || c.boxShadow !== 'none' || ['Top', 'Right', 'Bottom', 'Left'].some(k => c['border' + k + 'Style'] !== 'none' && parseFloat(c['border' + k + 'Width']) > 0);
      if (e !== body && paints && c.position === 'static' && c.display !== 'inline' && !inPin(e)) {
        const stacks = x => { const q = getComputedStyle(x); return (q.position !== 'static' && q.zIndex !== 'auto') || +q.opacity < 1 || q.transform !== 'none' || q.isolation === 'isolate' || q.filter !== 'none' || q.mixBlendMode !== 'normal'; };
        const pd = e.parentElement ? getComputedStyle(e.parentElement).display : 'block';
        if (!(c.zIndex !== 'auto' && /flex|grid/.test(pd)) && !stacks(e)) {
          let m = 0;
          for (const d of e.querySelectorAll('*')) {
            const q = getComputedStyle(d), z = parseInt(q.zIndex);
            if (q.position === 'static' || q.position === 'fixed' || !(z > m)) continue;
            let open = true;
            for (let a = d.parentElement; a && a !== e; a = a.parentElement) if (stacks(a)) { open = false; break; }
            if (open) m = z;
          }
          if (m > 0) { o.position = 'relative'; o['z-index'] = String(m); }
        }
      }
      if (e === body) { o.height = H + 'px'; o['min-height'] = '0px'; o['overflow-x'] = o['overflow-y'] = 'visible'; o.position = 'relative'; }
      if (sc !== root && sc !== body) for (let a = sc; a && a !== root; a = a.parentElement) if (a === e) { o.height = H + 'px'; o['max-height'] = 'none'; o['overflow-x'] = o['overflow-y'] = 'visible'; }
      return Object.keys(o).length ? o : null;
    };
    // Balanced / pretty line breaking (text-wrap) is switched off by the build's own typing markup, so those blocks would wrap differently than the original. Their line breaks are measured here, character by character, and written as <br> at the start of every line after the first.
    const flowBox = x => { const d = getComputedStyle(x).display; return d === 'inline' || d === 'contents'; };
    const blockOf = x => { let a = x.parentElement; while (a && a !== body && a !== root && flowBox(a)) a = a.parentElement; return a; };
    const lineMap = new Map(), lineDone = new WeakSet();
    const lineStarts = n => {
      const a = blockOf(n);
      if (!a || a === body || a === root) return null;
      if (!lineDone.has(a)) {
        lineDone.add(a);
        const ca = getComputedStyle(a);
        if (/^(pretty|balance)$/.test(ca.textWrapStyle) && ca.whiteSpaceCollapse === 'collapse' && ca.textWrapMode === 'wrap' && ca.direction === 'ltr' && ca.textAlign !== 'justify' && /^(block|list-item|flow-root|inline-block)$/.test(ca.display)) {
          const tw = document.createTreeWalker(a, NodeFilter.SHOW_TEXT), rg = document.createRange();
          let last = null;
          for (let t = tw.nextNode(); t; t = tw.nextNode()) {
            if (blockOf(t) !== a || t.parentElement.closest('svg,script,style,noscript,template')) continue;
            for (let i = 0; i < t.data.length; i++) {
              const ch = t.data.charCodeAt(i);
              if (ch === 32 || ch === 9 || ch === 10 || ch === 13 || ch === 12 || (ch >= 0xDC00 && ch <= 0xDFFF)) continue;   // collapsible white space has no reliable box
              rg.setStart(t, i); rg.setEnd(t, i + 1);
              const r = [...rg.getClientRects()].find(q => q.height > 0 && q.width > 0);
              if (!r) continue;
              if (last && (r.left < last.left - 1 || r.top >= last.top + last.height * 0.7)) { if (!lineMap.has(t)) lineMap.set(t, []); lineMap.get(t).push(i); }
              last = r;
            }
          }
        }
      }
      return lineMap.get(n) || null;
    };
    const node = (n, pc, svgRoot, inPinned) => {
      if (n.nodeType === 3) {
        // A text run directly inside a flex/grid container is its own anonymous item, and the whitespace at its edges is collapsed away in the original.
        // The build wraps that run in a span, which turns a trailing space into a real one: in a pinned-width box (chip, pill, button) the line wraps and the label jumps up. So edge whitespace is dropped here, as the browser dropped it. (Only CSS whitespace: a no-break space stays.)
        let d = n.data;
        if (pc && /flex|grid/.test(pc.display) && !/^(pre|break)/.test(pc.whiteSpace)) {
          if (!(n.previousSibling && n.previousSibling.nodeType === 3)) d = d.replace(/^[ \t\n\r\f]+/, '');
          if (!(n.nextSibling && n.nextSibling.nodeType === 3)) d = d.replace(/[ \t\n\r\f]+$/, '');
          return esc(d);
        }
        const brk = lineStarts(n);
        if (!brk) return esc(d);
        let out = '', at = 0;
        for (const i of brk) { out += esc(d.slice(at, i)) + '<br>'; at = i; }
        return out + esc(d.slice(at));
      }
      if (n.nodeType !== 1) return '';
      const e = n, tag = e === body ? 'div' : e.localName;
      if (SKIP_TAG.has(tag) || e.hasAttribute('data-cap-out') || e === frame) return '';
      if (pinHtml.has(e)) {
        const p = pins.find(q => q.el === e);
        return p.panels > 1 ? `<div style="display:block;position:relative;flex:none;width:${e.getBoundingClientRect().width}px;height:${p.h * p.panels}px">${pinHtml.get(e)}</div>` : pinHtml.get(e);
      }
      const c = getComputedStyle(e), svg = e.namespaceURI === 'http://www.w3.org/2000/svg', inner = svg && tag !== 'svg';
      if (c.display === 'none' && !(tag === 'svg' && e.querySelector('symbol,defs')) && !inner) return '';
      let over = overFor(e, c);
      if (c.position === 'fixed' && inPinned && C.pinBox) {
        const r = e.getBoundingClientRect();
        over = { ...(over || {}), position: 'absolute', left: (r.left - C.pinBox.left) + 'px', top: (r.top - C.pinBox.top) + 'px', right: 'auto', bottom: 'auto', width: r.width + 'px', height: r.height + 'px', transform: 'none' };
      } else if (c.position === 'fixed' && !inPinned) {
        const r = e.getBoundingClientRect(), full = r.width >= innerWidth * 0.95 && r.height >= innerHeight * 0.95;
        over = { ...(over || {}), position: 'absolute', left: r.left + 'px', top: (full ? 0 : r.top) + 'px', right: 'auto', bottom: 'auto', width: r.width + 'px', height: (full ? H : r.height) + 'px', 'margin-top': '0px', 'margin-left': '0px', 'margin-right': '0px', 'margin-bottom': '0px', transform: 'none' };
        pinned.push(render(e, c, null, tag, svg, inner, over, true));
        return '';
      }
      return render(e, c, pc, tag, svg, inner, over, inPinned);
    };
    const render = (e, c, pc, tag, svg, inner, over, inPinned) => {
      const shot = e.getAttribute('data-cap-shot');
      if (shot) return `<img src="${esc(shot)}" alt="" style="${esc(styleOf(c, 'img', pc, false, false, over))}">`;
      const remote = e.getAttribute('data-cap-url');
      if (remote) return `<img src="${esc(tok(remote))}" alt="" style="${esc(styleOf(c, 'img', pc, false, false, over))}">`;
      if (tag === 'canvas' || tag === 'video' || tag === 'iframe' || tag === 'object' || tag === 'embed') return `<div style="${esc(styleOf(c, 'div', pc, false, false, over))}"></div>`;
      const attrs = [];
      if (svg) { for (const a of e.attributes) { if (/^on|^style$|^class$|^data-cap|^id$/i.test(a.name) && !(a.name === 'id')) continue; let v = a.value; if (/href$/i.test(a.name) && v && !v.startsWith('#') && !v.startsWith('data:')) v = tok(new URL(v, location.href).href); attrs.push(`${a.name}="${esc(v)}"`); } }
      else for (const a of HTML_ATTR) if (e.hasAttribute(a) && !(tag === 'img' && (a === 'width' || a === 'height'))) attrs.push(`${a}="${esc(e.getAttribute(a))}"`);
      if (tag === 'a') attrs.push('href="#"');
      if (tag === 'img') attrs.push(`src="${esc(tok(e.currentSrc || e.src))}"`);
      if (tag === 'input') { if (e.value) attrs.push(`value="${esc(e.value)}"`); if (e.checked) attrs.push('checked'); }
      if (tag === 'option' && e.selected) attrs.push('selected');
      const st = styleOf(c, tag, pc, svg, inner, over, e);
      if (st) attrs.push(`style="${esc(st)}"`);
      const open = `<${tag}${attrs.length ? ' ' + attrs.join(' ') : ''}>`;
      if (VOID.has(tag)) return open;
      if (tag === 'textarea') return open + esc(e.value) + `</${tag}>`;
      let inside = svg ? '' : pseudo(e, '::before', c);
      if (tag !== 'picture') for (const k of kids(e)) inside += node(k, c, null, inPinned);
      else { const im = e.querySelector('img'); if (im) inside += node(im, c, null, inPinned); }   // the wrapper stays: grid cell, position and margins live on it
      if (!svg) inside += pseudo(e, '::after', c);
      return open + inside + `</${tag}>`;
    };
    C.ser = { node, esc, tok, urls, pinned, H, frame, pinHtml, root, body, pins };
    C.freezePin = i => {
      const p = pins[i], e = p.el, c = getComputedStyle(e);
      C.pinBox = e.getBoundingClientRect();
      const o = { position: 'relative', left: 'auto', top: 'auto', right: 'auto', bottom: 'auto', transform: 'none', 'margin-top': '0px', 'margin-bottom': '0px' };
      pinHtml.set(e, (pinHtml.get(e) || '') + render(e, c, getComputedStyle(e.parentElement), e.localName, false, false, o, true));
      C.pinBox = null;
    };
  };
  C.freeze = () => {
    C.prepare();
    const { node, esc, tok, urls, pinned, H, frame, root, body } = C.ser;
    const rc = getComputedStyle(root), bc = getComputedStyle(body);
    const clear = s => !s || /rgba\(0, 0, 0, 0\)|transparent/.test(s);
    const bg = !clear(bc.backgroundColor) ? bc.backgroundColor : !clear(rc.backgroundColor) ? rc.backgroundColor : 'rgb(255, 255, 255)';
    const bgImage = bc.backgroundImage === 'none' && rc.backgroundImage !== 'none' ? rc.backgroundImage : 'none';
    const main = node(body, null, null, false);
    frame.remove();
    const bgi = bgImage === 'none' ? '' : `;background-image:${bgImage.replace(/url\("([^"]+)"\)/g, (m, u) => `url("${tok(u)}")`)};background-size:${rc.backgroundSize}`;
    // isolation:isolate: the page background sits on this wrapper in the build (in the original on the root). Without its own stacking context a layer with z-index:-1 (page-wide light canvas, glows) would paint BEHIND the background and vanish.
    const html = `<div data-frozen style="position:relative;isolation:isolate;width:${innerWidth}px;height:${H}px;overflow:hidden;background-color:${bg}${esc(bgi)}">${main}${pinned.join('')}</div>`;
    return { html, urls, height: H, title: document.title, lang: root.lang || 'en', bg, elements: document.querySelectorAll('*').length, accent: C.accent(), styles: [...document.querySelectorAll('style')].map(s => s.textContent).join('\n') };
  };
}

// ---------- capture ----------
console.log('Opening', url);
await page.goto(url, { waitUntil: 'load', timeout: 90000 });
await page.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {});
await page.evaluate(install);
await page.mouse.move(W / 2, VH / 2);
await wait(1200);
let overlays = await page.evaluate(() => __cap.clearOverlays());

// Scroll through once with real wheel input, so lazy images, reveals and scroll-driven states all fire
const step = 700;
let height = await page.evaluate(() => __cap.height()), y = 0, steps = 0;
while (y < height - VH && y < MAX_H && steps < 200) {
  y += step; steps++;
  await page.mouse.wheel(0, step);
  await wait(130);
  const now = await page.evaluate(() => __cap.scrollY());
  if (Math.abs(now - y) > step * 0.7) await page.evaluate(v => __cap.scrollTo(v), y);
  await wait(130);
  // Wait until the middle of the screen stops moving (smooth scrolling and scrubbed reveals lag behind the wheel), at most 2 s, then take its state
  for (let k = 0, prev = null; k < 16; k++) {
    const sg = await page.evaluate(() => __cap.sig());
    if (sg === prev) break;
    prev = sg; await wait(130);
  }
  overlays += await page.evaluate(() => { __cap.remember(); __cap.settle(); return __cap.clearOverlays(); });
  height = await page.evaluate(() => __cap.height());
}
await page.evaluate(() => __cap.scrollTo(0));
await page.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {});
await page.waitForFunction(() => [...document.images].every(i => i.complete), null, { timeout: 12000 }).catch(() => {});
await page.evaluate(() => document.fonts.ready);
await wait(900);
overlays += await page.evaluate(() => { __cap.settle(); __cap.remember(); return __cap.clearOverlays(); });
height = Math.min(await page.evaluate(() => __cap.height()), MAX_H);

// Canvas, WebGL, video and embeds become stills of their real state, each in its own place and without what lies on top of them
const ffmpegPath = () => [process.env.FFMPEG_PATH, 'ffmpeg'].find(c => c && !spawnSync(c, ['-version']).error) || (() => { try { return require('ffmpeg-static'); } catch { return null; } })();
let stills = 0;
async function still(h) {
  const box0 = await h.boundingBox().catch(() => null);
  if (!box0 || box0.width < 8 || box0.height < 8) return;
  const v = await h.evaluate(e => (e.localName === 'video' ? { ready: e.readyState >= 2 && e.videoWidth > 0, poster: e.poster, src: e.currentSrc || e.src || (e.querySelector('source') || {}).src || '' } : null));
  if (v && !v.ready && v.poster) { await h.evaluate((e, u) => e.setAttribute('data-cap-url', u), v.poster); return; }
  const file = `still-${++stills}.png`, rel = 'assets/' + file, dest = path.join(ASSETS, file);
  let ok = false;
  // A 2D canvas hands over its exact pixels with alpha. A word window punched into one survives only this way, whatever lies under it and however far it overhangs the window.
  const direct = await h.evaluate(e => { if (e.localName !== 'canvas' || !e.width || !e.height) return null; try { return e.getContext('2d') ? e.toDataURL('image/png').split(',')[1] : null; } catch { return null; } }).catch(() => null);
  if (direct) { fs.writeFileSync(dest, Buffer.from(direct, 'base64')); ok = true; }
  if (v && !v.ready && v.src) { const ff = ffmpegPath(); if (ff) ok = spawnSync(ff, ['-v', 'error', '-y', '-ss', '1', '-i', v.src, '-frames:v', '1', dest]).status === 0; }
  if (!ok) {
    await h.evaluate(e => __cap.isolate(e));
    await wait(120);
    const b = await h.boundingBox();
    const clip = b && { x: Math.max(0, b.x), y: Math.max(0, b.y), width: Math.min(b.width, W - Math.max(0, b.x)), height: Math.min(b.height, VH - Math.max(0, b.y)) };
    if (b && b.height > VH - Math.max(0, b.y) + 2 && clip.width > 4) {
      // Taller than the window (a page-high light or effect canvas): shoot it in window-high slices and stitch them. One clipped shot would be stretched over the whole height in the build and lose everything below the first screen.
      const top0 = await h.evaluate(e => e.getBoundingClientRect().top + __cap.scrollY()), H = Math.min(Math.round(b.height), MAX_H), parts = [];
      let lastY = null;
      for (let off = 0; off < H; off += VH) {
        await page.evaluate(v => __cap.scrollTo(v), top0 + off);
        await wait(150);
        const bb = await h.boundingBox(), vis = Math.max(0, bb.y);
        if (lastY !== null && Math.abs(bb.y - lastY) < 2) break;   // pinned: it did not move, another slice would only paint a later scroll state over the first
        lastY = bb.y;
        const buf = await page.screenshot({ type: 'png', omitBackground: true, clip: { x: clip.x, y: vis, width: clip.width, height: Math.min(VH - vis, H + bb.y - vis) } }).catch(() => null);
        if (buf) parts.push({ at: Math.round(vis - bb.y), data: buf.toString('base64') });
      }
      if (parts.length) {
        const helper = await ctx.newPage();
        const png = await helper.evaluate(async ([ps, w, h]) => {
          const cv = document.createElement('canvas'); cv.width = w; cv.height = h; const g = cv.getContext('2d');
          for (const p of ps) { const m = await new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = no; i.src = 'data:image/png;base64,' + p.data; }); g.clearRect(0, p.at, w, m.height); g.drawImage(m, 0, p.at); }
          return cv.toDataURL('image/png').split(',')[1];
        }, [parts, Math.round(clip.width), H]);
        await helper.close();
        fs.writeFileSync(dest, Buffer.from(png, 'base64')); ok = true;
      }
      await page.evaluate(v => __cap.scrollTo(v), top0);
      await wait(150);
    } else if (clip && clip.width > 4 && clip.height > 4) ok = await page.screenshot({ path: dest, type: 'png', omitBackground: true, clip }).then(() => true).catch(() => false);
    await page.evaluate(() => __cap.isolate(null));
  }
  if (ok) await h.evaluate((e, r) => e.setAttribute('data-cap-shot', r), rel);
}

// Spots for the comparison with the original: every pin panel at its frozen state, plus evenly spread spots on the normal parts of the page
const pins = await page.evaluate(() => __cap.findPins());
await page.evaluate(() => __cap.prepare());
const spots = [];
let fold = 0, free = [], cursor = 0;
for (const [i, p] of pins.entries()) {
  free.push({ a: cursor, b: p.top, off: fold });
  for (let j = 0; j < p.panels; j++) spots.push({ y: p.top + (p.travel * (j + 0.5)) / p.panels, buildY: Math.round(p.top - fold + j * p.h), pin: i, panel: j });
  fold += p.travel - (p.panels - 1) * p.h; cursor = p.top + p.h + p.travel;
}
free.push({ a: cursor, b: height, off: fold });
free = free.filter(r => r.b - r.a >= VH);
const room = Math.max(5, 18 - spots.length), total = free.reduce((s, r) => s + (r.b - r.a - VH), 0) || 1;
for (const r of free) {
  const span = r.b - r.a - VH, k = Math.max(1, Math.round(room * span / total));
  for (let i = 0; i <= (span < 40 ? 0 : k - 1); i++) { const y = Math.round(r.a + (k > 1 ? span * i / (k - 1) : 0)); spots.push({ y, buildY: y - r.off }); }
}
spots.sort((a, b) => a.y - b.y);
const shots = [];
for (const [i, s] of spots.entries()) {
  let y = Math.round(s.y);
  if (s.pin != null) {
    // Each panel takes the moment of its stretch that shows the most. The first panel of a pin at the very top stays the page's own first view.
    const p = pins[s.pin], a = s.panel / p.panels, b = (s.panel + 1) / p.panels;
    if (p.top < 40 && s.panel === 0) y = Math.round(p.top);
    else {
      let best = -1;
      for (const q of [0.2, 0.5, 0.8]) {
        const c = Math.round(p.top + p.travel * (a + (b - a) * q));
        await page.evaluate(([v, top]) => { __cap.scrollTo(v); __cap.pinned(top); }, [c, false]);
        await wait(550);
        const sc = await page.evaluate(k => __cap.pinScore(k), s.pin);
        if (sc >= best) { best = sc; y = c; }
      }
    }
  }
  await page.evaluate(([v, top]) => { __cap.scrollTo(v); __cap.pinned(top); }, [y, y === 0]);
  await wait(i ? 1000 : 500);
  if (i === spots.length - 1) await wait(1500);
  await page.evaluate(() => __cap.settle());
  if (s.pin == null) await page.evaluate(() => __cap.remember());
  const file = `${String(i).padStart(2, '0')}.jpg`;
  await page.screenshot({ path: path.join(OUT, file), type: 'jpeg', quality: 92 });
  shots.push({ file, y: s.buildY, original: y, pin: s.pin != null });
  if (s.pin != null) {
    const inside = await page.evaluateHandle(k => [...__cap.pins[k].el.querySelectorAll('canvas,video,iframe,object,embed')], s.pin);
    for (const h of await inside.getProperties().then(m => [...m.values()].map(x => x.asElement()).filter(Boolean))) await still(h);
    await page.evaluate(k => __cap.freezePin(k), s.pin);
  }
}
await page.evaluate(() => { __cap.scrollTo(0); __cap.pinned(false); });
await wait(600);
for (const h of await page.$$('canvas:not([data-cap-shot]), video:not([data-cap-shot]):not([data-cap-url]), iframe:not([data-cap-shot]), object, embed')) {
  if (await h.evaluate(e => __cap.pins && __cap.pins.some(p => p.el.contains(e)))) continue;
  const y = await h.evaluate(e => { const r = e.getBoundingClientRect(); return r.width > 8 && r.height > 8 ? Math.max(0, r.top + __cap.scrollY()) : -1; });
  if (y < 0) continue;
  await page.evaluate(v => __cap.scrollTo(v), y);
  await wait(450);
  await still(h);
}
await page.evaluate(() => { __cap.scrollTo(0); __cap.pinned(true); });
await wait(500);
await page.evaluate(() => { __cap.settle(); __cap.remember(); });
// The top reference is taken in the same moment the page is frozen, so a running carousel shows the same slide in both
if (shots[0] && shots[0].original === 0 && !shots[0].pin) await page.screenshot({ path: path.join(OUT, shots[0].file), type: 'jpeg', quality: 92 });

const F = await page.evaluate(() => __cap.freeze());

// ---------- assets ----------
const EXT = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'image/avif': '.avif', 'image/gif': '.gif', 'image/svg+xml': '.svg', 'font/woff2': '.woff2', 'font/woff': '.woff', 'font/ttf': '.ttf', 'font/otf': '.otf', 'application/font-woff2': '.woff2', 'application/font-woff': '.woff' };
async function fetchAsset(u) {
  if (u.startsWith('file:')) return { body: fs.readFileSync(fileURLToPath(u)), type: '' };
  if (u.startsWith('blob:')) { const b = await page.evaluate(async x => { const r = await fetch(x), a = new Uint8Array(await r.arrayBuffer()); return { t: r.headers.get('content-type') || '', d: [...a] }; }, u); return { body: Buffer.from(b.d), type: b.t }; }
  const r = responses.get(u);
  if (r) { try { return { body: await r.body(), type: r.headers()['content-type'] || '' }; } catch {} }
  const g = await ctx.request.get(u, { headers: { referer: url }, timeout: 30000 });
  if (!g.ok()) throw new Error('HTTP ' + g.status());
  return { body: await g.body(), type: g.headers()['content-type'] || '' };
}
const saved = new Map(), failed = [];
async function save(u, prefix) {
  if (saved.has(u)) return saved.get(u);
  try {
    const a = await fetchAsset(u), type = (a.type.split(';')[0] || '').trim();
    const ext = EXT[type] || (path.extname(new URL(u).pathname).slice(0, 6) || '.bin');
    const name = `${prefix}-${saved.size + 1}${ext}`;
    fs.writeFileSync(path.join(ASSETS, name), a.body);
    saved.set(u, 'assets/' + name); return 'assets/' + name;
  } catch (e) { failed.push(u.slice(0, 120)); saved.set(u, u); return u; }
}
const paths = [];
for (let i = 0; i < F.urls.length; i += 8) paths.push(...await Promise.all(F.urls.slice(i, i + 8).map(u => save(u, 'img'))));
let html = F.html.replace(/__CAPASSET(\d+)__/g, (m, i) => paths[+i]);
// A CSS mask image loads with CORS and a file:// page has no origin: the mask fails silently and what it should cut stays uncut. Masks go into the page itself.
const MASK_TYPE = { '.svg': 'image/svg+xml', '.png': 'image/png', '.webp': 'image/webp', '.avif': 'image/avif', '.jpg': 'image/jpeg', '.gif': 'image/gif' };
html = html.replace(/((?:-webkit-)?mask(?:-image)?\s*:)((?:&quot;|[^;"])*)/g, (m, prop, value) => prop + value.replace(/assets\/[\w.-]+/g, f => {
  const type = MASK_TYPE[path.extname(f)];
  return type ? `data:${type};base64,${fs.readFileSync(f).toString('base64')}` : f;
}));

// ---------- fonts: only faces the original really loaded ----------
const css = [{ text: F.styles, base: url }];
for (const r of sheets) { try { css.push({ text: await r.text(), base: r.url() }); } catch {} }
const faces = []; let fontFiles = 0;
const loaded = new Set([...responses.keys()].filter(u => responses.get(u).request().resourceType() === 'font'));
for (const { text, base } of css) {
  for (const block of text.match(/@font-face\s*{[^}]*}/g) || []) {
    const srcs = [...block.matchAll(/url\(\s*['"]?([^'")]+)['"]?\s*\)/g)].map(m => { try { return new URL(m[1], base).href; } catch { return m[1]; } });
    const hit = srcs.find(s => loaded.has(s)) || srcs.find(s => s.startsWith('data:'));
    if (!hit) continue;
    const local = hit.startsWith('data:') ? hit : await save(hit, 'font');
    if (!hit.startsWith('data:')) fontFiles++;
    const keep = block.replace(/src\s*:[^;}]*(;|(?=}))/g, '').replace(/}\s*$/, `;src:url("${local}")}`).replace(/;;+/g, ';');
    if (!faces.includes(keep)) faces.push(keep);
  }
}

const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
const accent = F.accent ? ` data-accent="${F.accent}"` : '';
const label = LABEL ? ` data-url="${esc(LABEL)}"` : '';
const doc = `<!doctype html><html lang="${esc(F.lang)}"><head><meta charset="utf-8"><meta name="viewport" content="width=1920"><title>${esc(F.title)}</title>
<style>${faces.join('\n')}
html,body{margin:0;padding:0}body{background:${F.bg}}</style></head><body>${html}
<script src="agents.js"${accent}${label} data-title="${esc(F.title.slice(0, 60))}"></script></body></html>\n`;
fs.writeFileSync('index.html', doc);
fs.writeFileSync(path.join(OUT, 'shots.json'), JSON.stringify({ url, shots, height: F.height, width: W, viewport: VH }));
await br.close();
console.log(JSON.stringify({ file: path.resolve('index.html'), sizeMB: +(doc.length / 1e6).toFixed(1), height: F.height, elements: F.elements, images: paths.length, imagesFailed: failed.length, failedList: failed.slice(0, 5), fonts: fontFiles, stills, pinnedPanels: pins.length, overlaysLeftOut: overlays, referenceShots: shots.length, accent: F.accent || null }));